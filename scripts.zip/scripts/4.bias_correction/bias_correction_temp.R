#########################################
# Author - Andre Moraes
# Updated by Sajad Khoshnood
# Utah State University
# QCNR - Watershed Sciences Department
# andre.moraes@usu.edu & sajad.khoshnoodmotlagh@usu.edu

# This script is used to bias corrected GCM temperatures data by Equidistant Quantile Mapping 

################################################################
# Loading required packages
library(sp)
library(ncdf4)
library(dplyr)
library(randomForest)
library(Metrics)
library(doParallel)
library(spam)
library(foreign)

### Set the working directory
setwd("/scratch/general/vast/u6055107/climava_nw/bias_correction")
# Confirm the directory is set correctly.
getwd() 


# Load necessary files for guiding the loops
models <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/models_2024.csv") 
variables <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/Variables.csv")

# Define scenarios and variables for processing
ssps <- c("historical","ssp245","ssp370","ssp585")
vars <- c("pr", "tasmax", "tasmin")

#################################
# Looping through variables and models
for (v in 2:3){ # tasmx and tasmin
  
  var <- paste(variables[v,3])
  print(var)
  
  for(m in 1:17) {
      
    model = models[m,1]
    print(model)
    
    #loading the guide with the coordinates for each pixel of respective GCM
    guide <- read.dbf(paste0("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/guides/",model,"_guide.dbf"))
    guide$lon1 <- ifelse(guide$lon < 0, (360 + guide$lon), guide&lon)# Adjust longitude to positive range if needed
    guide <- guide[,c(4,1:2,5,3)]# Reorder columns for consistency
    
    realization <- models[m,5] # Extract realization information (e.g., model ensemble member)
    
    # Open and read resampled PRISM file for each model
    nc1 <- nc_open(paste0("/scratch/general/vast/u6055107/climava_nw/resample_compressed/prism_",var,"_day_",model,"_resampled.nc"))  
    
    lon <- unique(ncvar_get(nc1, "lon"))  # Extract unique longitude values
    lon_res <- abs(lon[1] - lon[2])  # Calculate longitude resolution
    lat_lenght <- length(ncvar_get(nc1, "lat"))  # Get the number of latitude points
    lat <- unique(ncvar_get(nc1, "lat"))  # Extract unique latitude values
    lat_res <- abs(lat[1] - lat[2])  # Calculate latitude resolution
    
    prism_array <- ncvar_get(nc1, var)  # Extract PRISM data as an array
    rm(nc1)  # Free memory
    
    
    # Open historical GCM data
    nc_hist <- nc_open(paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_subset/",model,"/historical/",var,"/",var,"_day_",model,"_",realization,"_historical_subset.nc")) # GCM historical
    
    hist_array <- ncvar_get(nc_hist, var) # Extract historical data
    rm(nc_hist)
    
    #s=2
    for (s in 1:4){ # Loop through scenarios
        
      ssp = ssps[s]
      print(ssp)
      
      # Open GCM data for the current scenario
      nc <- nc_open(paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_subset/",model,"/", ssp,"/",var,"/",var,"_day_",model,"_",realization,"_", ssp,"_subset.nc"))
  
      to_bc_array <- ncvar_get(nc, var) # Extract data to be bias-corrected
      
      
      if (ssp == "historical"){ # if historical, QM
      
      registerDoParallel(50)
        
        #i=9
        data <- foreach (i = 1: length(guide[,1]), .combine=cbind, .multicombine = T,
                         .packages = c("doParallel","foreach","ncdf4","dplyr", "Metrics")) %dopar% {
                           
                           # Extract pixel-specific coordinates
                           guide_lon <- guide[i,2] # get central coordinates (lon flip)
                           guide_lat <- guide[i,3] # get central coordinates
                           
                           # Calculate indices for PRISM and GCM data
                           X <- round((guide_lon - lon[1]) / lon_res,0) + 1 
                           Y <- as.double(round(lat_lenght - abs((guide_lat - tail(lat,1))/lat_res))) 
                           
                           prism_vector <- prism_array[X,Y,1:12410] # Extract PRISM time series (1981-2014)
                           
                           hist_vector <-  hist_array[X,Y,1:12410] # Extract historical GCM time series (1981-2014)
                           hist_vector <- (round((hist_vector - 273.5),1)) # Convert units from per second to daily
                           
                           if (is.na(prism_vector[1]) == TRUE) {
                             
                             pixel = rep(NA, 12410) # Assign NA if PRISM pixel is located outside of the study area border
                             
                           }
                           else{
                             
                             to_bc_vector <-  to_bc_array[X,Y,1:12410] # Extract time series to be bias-corrected
                             to_bc_vector <- (round((to_bc_vector - 273.5),1)) # Convert units
                             
                             # Calculate empirical cumulative distribution functions (ECDFs)
                             prism_cdf <- ecdf(prism_vector) # calculating Prism CDF
                             hist_cdf <- ecdf(hist_vector) #calculating Prism CDF
                             
                             probability <- hist_cdf(to_bc_vector) # getting probabilities for variables to be corrected  based on the historical CDF
                             pixel <- quantile(prism_cdf, probability) # using probabilities to get bias corrected values from the Prism cdf.
                             
                           }
                           
                           cbind(pixel)  # Combine results
                           
                         }
        
        # Build the NetCDF output for historical scenario
        data <- as.data.frame(data)
        rownames(data) <- as.character(1:length(data[,1]))
        colnames(data) <- as.character(1:length(data))
        data <- t(data)
        
        # Define dimensions for NetCDF
        LON_n <- length(unique(guide$lon)) 
        LAT_n <- length(unique(guide$lat))
        TIME_n <- 12410 
        
        # Create data array
        data_array <-  array(data, dim = c(LON_n, LAT_n, TIME_n))
        
        # Define metadata for the NetCDF
        nc_name <- paste0(ssp,"_",var,"_day_",model,"_EDCDFm.nc")
        dim_name <- variables[v,3]
        dim_long_name <- variables[v,5]
        dim_units <- variables[v,6]
        
        ##defining dimensions
        lon_dim <- ncdim_def("lon", units = "degrees_east", longname = "Longitude", vals = unique(guide$lon))
        lat_dim <- ncdim_def("lat", units = "degrees_north", longname = "Latitude", vals = unique(guide$lat))
        time_dim <- ncdim_def("time", units = "days", longname = "days since start", vals = seq(1,12410,1))
        
        # Define variable dimensions
        variable_dim <- ncvar_def(name = dim_name, units = dim_units, list(lon_dim, lat_dim, time_dim),
                                  missval = NA,longname = dim_long_name, prec = "double")
        
        # Create and populate the NetCDF file
        nc_out <- nc_create(nc_name,variable_dim)
        
        ncvar_put(nc_out, variable_dim, data_array)
        
        nc_close(nc_out)
        
      }
      
      if(ssp == "ssp245"|ssp == "ssp370"|ssp == "ssp585"){
        
        data <- foreach (i = 1: length(guide[,1]), .combine=cbind, .multicombine = T,
                         .packages = c("spam","doParallel","foreach","ncdf4","dplyr", "Metrics")) %dopar% {
                           
                           # Extract pixel-specific coordinates
                           guide_lon <- guide[i,2] # get central coordinates (lon flip)
                           guide_lat <- guide[i,3] # get central coordinates
                           
                           # Calculate indices for PRISM and GCM data
                           X <- round((guide_lon - lon[1]) / lon_res,0) + 1 
                           Y <- as.double(round(lat_lenght - abs((guide_lat - tail(lat,1))/lat_res))) 
                           
                           prism_vector <- prism_array[X,Y,1:12410] # PRISM data for bias correction reference
                           
                           hist_vector <-  hist_array[X,Y,1:12410] # Historical GCM reference data
                           hist_vector <- (round((hist_vector - 273.5),1)) # Convert units
                           
                           if (is.na(prism_vector[1]) == TRUE) {
                             
                             pixel = rep(NA, 31390) # Assign NA if PRISM pixel is located outside of the border
                             
                           }
                           else{
                             
                             to_bc_vector <-  to_bc_array[X,Y,1:31390] # Data to be bias corrected (2015 - 2100)
                             to_bc_vector <- (round((to_bc_vector - 273.5),1)) 
                             
                             # Compute CDFs for PRISM and historical data
                             prism_cdf <- ecdf(prism_vector) # calculating Prism CDF
                             hist_cdf <- ecdf(hist_vector) #calculating hist CDF
                             
                             #splitting future in "30" year chunks
                             to_bc_vector_1 <- to_bc_vector[1:9490] #2015 - 2040
                             to_bc_vector_2 <- to_bc_vector[9491:20440] #2041 - 2070
                             to_bc_vector_3 <- to_bc_vector[20441:31390] #2071 - 2100
                             
                             #CDF of each future chunk
                             vector_1_cdf <- ecdf(to_bc_vector_1)
                             vector_2_cdf <- ecdf(to_bc_vector_2)
                             vector_3_cdf <- ecdf(to_bc_vector_3)
                             
                             #probabilities from future chunks CDF
                             probability_1 <- vector_1_cdf(to_bc_vector_1)
                             probability_2 <- vector_1_cdf(to_bc_vector_2)
                             probability_3 <- vector_1_cdf(to_bc_vector_3)
                             
                             BC <- data.frame("p_f" = c(probability_1, probability_2, probability_3), "v_f" = to_bc_vector)
                             BC$v_h <- quantile(hist_cdf, BC$p_f) # historical value based on p_f
                             BC$v_ob <- quantile(prism_cdf, BC$p_f) # observed value based on p_f
                             BC$corrected <- (BC$v_f - BC$v_h) + BC$v_ob # bias corrected value
                             
                             pixel <- BC$corrected # separating pixel as a vector
                             
                           }
                           
                           cbind(pixel)
                           
                         }
        
        # creating the NetCDF
        data <- as.data.frame(data)
        rownames(data) <- as.character(1:length(data[,1]))
        colnames(data) <- as.character(1:length(data))
        data <- t(data)
        
        # NetCDF dmensions
        LON_n <- length(unique(guide$lon)) 
        LAT_n <- length(unique(guide$lat))
        TIME_n <- 31390 
        
        # creating array
        data_array <-  array(data, dim = c(LON_n, LAT_n, TIME_n))
        
        # naming
        nc_name <- paste0(ssp,"_",var,"_day_",model,"_EDCDFm.nc")
        dim_name <- variables[v,3]
        dim_long_name <- variables[v,5]
        dim_units <- variables[v,6]
        
        # defining dimensions
        lon_dim <- ncdim_def("lon", units = "degrees_east", longname = "Longitude", vals = unique(guide$lon))
        lat_dim <- ncdim_def("lat", units = "degrees_north", longname = "Latitude", vals = unique(guide$lat))
        time_dim <- ncdim_def("time", units = "days", longname = "days since start", vals = seq(1,31390,1))
        
        # variable dimensions
        variable_dim <- ncvar_def(name = dim_name, units = dim_units, list(lon_dim, lat_dim, time_dim),
                                  missval =  NA,longname = dim_long_name, prec = "double")
        # creating empty NectCDF
        nc_out <- nc_create(nc_name,variable_dim)
        
        # adding variable to NetCDF
        ncvar_put(nc_out, variable_dim, data_array)
        
        # closing NetCDF
        nc_close(nc_out)
        
      }
    }
  }
}  
  
  
  
  
  
  
