#########################################
# Author - Andre Moraes
# Updated by Sajad Khoshnood
# Utah State University
# QCNR - Watershed Sciences Department
# andre.moraes@usu.edu & sajad.khoshnoodmotlagh@usu.edu

# This script is used to bias correct GCM precipitation data by Quantile Mapping. 
# Quantile Mapping adjusts the distribution of model outputs to match observed data, 
# improving the representation of climate variables in the models.

################################################################
# Loading required packages
library(sp)            # Spatial data handling
library(ncdf4)         # NetCDF file processing
library(dplyr)         # Data manipulation
library(randomForest)  # Machine learning methods
library(Metrics)       # Performance metrics
library(doParallel)    # Parallel processing
library(spam)          # Sparse matrix algebra
library(foreign)       # Reading .dbf files

### Set the working directory
setwd("/scratch/general/vast/u6055107/climava_nw/bias_correction")
# Confirm the directory is set correctly.
getwd() 

# Set up parallel processing parameters
registerDoParallel(50)  # Register 50 cores for parallel computation

# Load necessary files for guiding the loops
models <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/models_2024.csv") 
variables <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/Variables.csv") 

# Define scenarios and variables for processing
ssps <- c("historical","ssp245","ssp370","ssp585")  # Scenarios: Historical and SSPs (future scenarios)
vars <- c("pr", "tasmax", "tasmin")  # Variables to process

#################################
# Looping through variables and models
for (v in 1){ # Only process precipitation (pr) for this script.
  
  var <- paste(variables[v,3])  # Extract variable name
  print(var)  # Display the variable being processed
  
  for(m in 1:17) { # Loop through all 17 models
    
    model = models[m,1]  # Extract model name
    print(model)  # Display the current model
    
    # Load the guide with pixel coordinates for the respective GCM
    guide <- read.dbf(paste0("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/guides/",model,"_guide.dbf"))
    guide$lon1 <- ifelse(guide$lon < 0, (360 + guide$lon), guide$lon)  # Adjust longitude to positive range if needed
    
    guide <- guide[,c(4,1:2,5,3)]  # Reorder columns for consistency
    
    realization <- models[m,5]  # Extract realization information (e.g., model ensemble member)
    
    # Open and read resampled PRISM file for each model
    nc1 <- nc_open(paste0("/scratch/general/vast/u6055107/climava_nw/resample_compressed/prism_",var,"_day_",model,"_resampled.nc")) 
    
    lon <- unique(ncvar_get(nc1, "lon"))  # Extract unique longitude values
    lon_res <- abs(lon[1] - lon[2])  # Calculate longitude resolution
    lat_lenght <- length(ncvar_get(nc1, "lat"))  # Get the number of latitude points
    lat <- unique(ncvar_get(nc1, "lat"))  # Extract unique latitude values
    lat_res <- abs(lat[1] - lat[2])  # Calculate latitude resolution
    
    prism_array <- ncvar_get(nc1, var)  # Extract PRISM data as an array
    rm(nc1)  # Free memory
    
    # Open historical GCM data
    nc_hist <- nc_open(paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_subset/",model,"/historical/",var,"/",var,"_day_",model,"_",realization,"_historical_subset.nc")) 
    hist_array <- ncvar_get(nc_hist, var)  # Extract historical data
    rm(nc_hist)  # Free memory
    
    s=1
    for (s in 1:4){  # Loop through scenarios
      
      ssp = ssps[s]  # Select the current scenario
      print(ssp)  # Display the scenario being processed
      
      # Open GCM data for the current scenario
      nc <- nc_open(paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_subset/",model,"/", ssp,"/",var,"/",var,"_day_",model,"_",realization,"_", ssp,"_subset.nc"))
      to_bc_array <- ncvar_get(nc, var)  # Extract data to be bias-corrected
      
      if (ssp == "historical"){
        
        data <- foreach (i = 1: length(guide[,1]), .combine=cbind, .multicombine = T,
                         .packages = c("doParallel","foreach","ncdf4","dplyr", "Metrics")) %dopar% {
                           
                           # Extract pixel-specific coordinates
                           guide_lon <- guide[i,2]  # Longitude
                           guide_lat <- guide[i,3]  # Latitude
                           
                           # Calculate indices for PRISM and GCM data
                           X <- round((guide_lon - lon[1]) / lon_res,0) + 1 
                           Y <- as.double(round(lat_lenght - abs((guide_lat - tail(lat,1))/lat_res))) 
                           
                           prism_vector <- prism_array[X,Y,1:12410]  # Extract PRISM time series (1981-2014)
                           
                           hist_vector <-  hist_array[X,Y,1:12410]  # Extract historical GCM time series (1981-2014)
                           hist_vector <- (round((hist_vector *86400),1))  # Convert units from per second to daily
                           
                           if (is.na(prism_vector[1]) == TRUE) {
                             
                             pixel = rep(NA, 12410)  # Assign NA if PRISM pixel is located outside of the study area border
                             
                           }
                           else{
                             
                             to_bc_vector <-  to_bc_array[X,Y,1:12410]  # Extract time series to be bias-corrected
                             to_bc_vector <- (round((to_bc_vector *86400),1))  # Convert units
                             
                             # Calculate empirical cumulative distribution functions (ECDFs)
                             prism_cdf <- ecdf(prism_vector)  # PRISM CDF
                             hist_cdf <- ecdf(hist_vector)  # Historical GCM CDF
                             
                             # Perform quantile mapping
                             probability <- hist_cdf(to_bc_vector)  # Get probabilities from historical CDF
                             pixel <- quantile(prism_cdf, probability)  # Map probabilities to PRISM CDF
                             
                           }
                           
                           cbind(pixel)  # Combine results
                         }
        
        # Build the NetCDF output for historical scenario
        data <- as.data.frame(data)
        rownames(data) <- as.character(1:length(data[,1]))
        colnames(data) <- as.character(1:length(data))
        data <- t(data)
        
        # Define dimensions for NetCDF
        LON_n <- length(unique(guide$lon)) 
        LAT_n <- length(unique(guide$lat))
        TIME_n <- 12410 
        
        # Create data array
        data_array <-  array(data, dim = c(LON_n, LAT_n, TIME_n))
        
        # Define metadata for the NetCDF
        nc_name <- paste0(ssp,"_",var,"_day_",model,"_BC.nc")
        dim_name <- variables[v,3]
        dim_long_name <- variables[v,5]
        dim_units <- variables[v,7]
        
        # Define NetCDF dimensions
        lon_dim <- ncdim_def("lon", units = "degrees_east", longname = "Longitude", vals = unique(guide$lon))
        lat_dim <- ncdim_def("lat", units = "degrees_north", longname = "Latitude", vals = unique(guide$lat))
        time_dim <- ncdim_def("time", units = "days", longname = "days since start", vals = seq(1,12410,1))
        
        # Define variable dimensions
        variable_dim <- ncvar_def(name = dim_name, units = dim_units, list(lon_dim, lat_dim, time_dim),
                                  missval =  NA,longname = dim_long_name, prec = "double")
        
        # Create and populate the NetCDF file
        nc_out <- nc_create(nc_name,variable_dim)
        ncvar_put(nc_out, variable_dim, data_array)
        nc_close(nc_out)  # Close the NetCDF file
      }
      
      if(ssp == "ssp245"|ssp == "ssp370"|ssp == "ssp585"){
        
        data <- foreach (i = 1: length(guide[,1]), .combine=cbind, .multicombine = T,
                         .packages = c("spam","doParallel","foreach","ncdf4","dplyr", "Metrics")) %dopar% {
                           
                           # Extract pixel-specific coordinates
                           guide_lon <- guide[i,2]
                           guide_lat <- guide[i,3]
                           
                           # Calculate indices for PRISM and GCM data
                           X <- round((guide_lon - lon[1]) / lon_res,0) + 1 
                           Y <- as.double(round(lat_lenght - abs((guide_lat - tail(lat,1))/lat_res))) 
                           
                           prism_vector <- prism_array[X,Y,1:12410]  # PRISM data for bias correction reference
                           
                           hist_vector <-  hist_array[X,Y,1:12410]  # Historical GCM reference data
                           hist_vector <- (round((hist_vector *86400),1))  # Convert units
                           
                           if (is.na(prism_vector[1]) == TRUE) {
                             
                             pixel = rep(NA, 31390)  # Assign NA if PRISM pixel is located outside of the border
                             
                           }
                           else{
                             
                             to_bc_vector <-  to_bc_array[X,Y,1:31390]  # Future GCM data
                             to_bc_vector <- (round((to_bc_vector *86400),1))  # Convert units
                             
                             # Calculate ECDFs
                             prism_cdf <- ecdf(prism_vector)  # PRISM CDF
                             hist_cdf <- ecdf(hist_vector)  # Historical CDF
                             
                             # Perform quantile mapping
                             probability <- hist_cdf(to_bc_vector)  # Get probabilities from historical CDF
                             pixel <- quantile(prism_cdf, probability)  # Map probabilities to PRISM CDF
                             
                           }
                           
                           cbind(pixel)  # Combine results
                         }
        
        # Build the NetCDF output for SSP scenarios
        data <- as.data.frame(data)
        rownames(data) <- as.character(1:length(data[,1]))
        colnames(data) <- as.character(1:length(data))
        data <- t(data)
        
        # Define dimensions for NetCDF
        LON_n <- length(unique(guide$lon)) 
        LAT_n <- length(unique(guide$lat))
        TIME_n <- 31390 
        
        # Create data array
        data_array <-  array(data, dim = c(LON_n, LAT_n, TIME_n))
        
        # Define metadata for the NetCDF
        nc_name <- paste0(ssp,"_",var,"_day_",model,"_BC.nc")
        dim_name <- variables[v,3]
        dim_long_name <- variables[v,5]
        dim_units <- variables[v,7]
        
        # Define NetCDF dimensions
        lon_dim <- ncdim_def("lon", units = "degrees_east", longname = "Longitude", vals = unique(guide$lon))
        lat_dim <- ncdim_def("lat", units = "degrees_north", longname = "Latitude", vals = unique(guide$lat))
        time_dim <- ncdim_def("time", units = "days", longname = "days since start", vals = seq(1,31390,1))
        
        # Define variable dimensions
        variable_dim <- ncvar_def(name = dim_name, units = dim_units, list(lon_dim, lat_dim, time_dim),
                                  missval =  NA,longname = dim_long_name, prec = "double")
        
        # Create and populate the NetCDF file
        nc_out <- nc_create(nc_name,variable_dim)
        ncvar_put(nc_out, variable_dim, data_array)
        nc_close(nc_out)  # Close the NetCDF file
      }
    }
  }
}
