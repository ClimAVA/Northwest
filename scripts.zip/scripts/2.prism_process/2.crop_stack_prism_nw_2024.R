########################################
# Author - Andre Moraes
# Updated by Sajad Khoshnood
# Utah State University
# QCNR - Watershed Sciences Department
# andre.moraes@usu.edu & sajad.khoshnoodmotlagh@usu.edu

# This script is used to crop and create netcdf files from prism files for the area of interest based on raw data of PRISM.


#loading required packages
library(raster)
library(lubridate)
library(ncdf4)
library(doParallel)

# loading shape file of the North West (including 5 states)
aoi <- shapefile("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/shp/AOI_2024_nw.shp")
#defining a vector for all three variables
vars <- c("tmax","tmin","ppt")

#objects for loop (we have the prism data from 1981 to 2023)
year_start <- as.character(seq(1981,2021,5))
year_end <- as.character(c(seq(1985,2020,5), seq(2023,2023,1)))

#dopar parameters
registerDoParallel(20) #setting number of cores

#####################################----
# i=1
# v=2

for (v in 1:length(vars)) {  #asking for all 3 variables
  var <- vars[v]
  print(var)
  print(Sys.time())
  
  foreach(i = 1:9, .packages = c("raster","lubridate","ncdf4")) %dopar% { # using foreach to run it parallel, i=1:9 is the number of years sections
    s = year_start[i]
    S = paste0(s,"0102") # to start the seq of days
    S1 = paste0(s,"0101") # to load the first raster for the stack
    e = year_end[i]
    E = paste0(e,"1231") #to end the seq of days
    
    days <- gsub("-", "", as.character(seq(ymd(S), ymd(E), by = "days")), "-") # sequence of of years with starting days
    
    #cropping the first day of each 5-year daily sequence and starting the stack
    daily_var <- raster(paste0("/scratch/general/vast/u6055107/climava_nw/prism/raw_1981-2023_",var,"/PRISM_",var,"_stable_4kmD2_",S1,"_bil/PRISM_",var,"_stable_4kmD2_",S1,"_bil.bil"))
    daily_var <- mask(daily_var, aoi)
    daily_var <- crop(daily_var, aoi)
    daily_var <- round(daily_var, digits = 1)
    daily_var <- stack(daily_var) 
    
    #cropping and staking all remaining days of the 5-year daily sequence 
    for(d in 1:length(days)){
      D = days[d]
      print(D)
      next_map <- raster(paste0("/scratch/general/vast/u6055107/climava_nw/prism/raw_1981-2023_",var,"/PRISM_",var,"_stable_4kmD2_",D,"_bil/PRISM_",var,"_stable_4kmD2_",D,"_bil.bil")) 
      next_map <- mask(next_map, aoi)
      next_map <- crop(next_map, aoi)
      next_map <- round(next_map, digits = 1)
      daily_var <- stack(daily_var, next_map)
    }
    
    #exporting/saving netcdf file based on each variable
    if (var=="tmax"){
      file_name <- paste0("/scratch/general/vast/u6055107/climava_nw/prism_nc_crop_stack/prism_nw_tasmax_",S1,"_",E,".nc")
      
      writeRaster(daily_var, file_name, overwrite = T, format ="CDF",
                  varname = "tasmax",varunit = "C", longname = "daily maximum air temperature",
                  xname = "lon", yname = "lat", zname = "time")
      rm(daily_var)
    }
    
    
    if (var=="tmin"){
      file_name <- paste0("/scratch/general/vast/u6055107/climava_nw/prism_nc_crop_stack/prism_nw_tasmin_",S1,"_",E,".nc")
      
      writeRaster(daily_var, file_name, overwrite = T, format ="CDF",
                  varname = "tasmin",varunit = "C", longname = "daily minimum air temperature",
                  xname = "lon", yname = "lat", zname = "time")
      rm(daily_var)
      
    }
    
    if (var=="ppt") {
      file_name <- paste0("/scratch/general/vast/u6055107/climava_nw/prism_nc_crop_stack/prism_nw_pr_",S1,"_",E,".nc")
      
      writeRaster(daily_var, file_name, overwrite = T, format ="CDF",
                  varname = "pr",varunit = "mm", longname = "daily precipittaion",
                  xname = "lon", yname = "lat", zname = "time")
      rm(daily_var)
      
    }
    
  }
  
}

