########################################
# Author - Andre Moraes
# Updated by Sajad Khoshnood
# Utah State University
# QCNR - Watershed Sciences Department
# andre.moraes@usu.edu & sajad.khoshnoodmotlagh@usu.edu

#this script has the purpose of stacking different years of prism data to have them as one file

#loading required packages
library(abind)
library(ncdf4)
library(dplyr)
library(randomForest)
library(Metrics)
library(doParallel)
library(spam)
library(foreign)
library(RNetCDF)

#loading necessary file to run the loops
vars <- c("pr", "tasmax", "tasmin")
variables <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/Variables.csv")
setwd("/scratch/general/vast/u6055107/climava_nw/prism_stacked_expanded")
time_period <- c("a","b","c")
####################################################################
#v=1
#asking for the number of cores to run the code
registerDoParallel(6)

for (v in 1:3) { #1:3 go through all 3 variables
  var <- variables[v,3]
  print(var)
  foreach (p = 1:3, #we aims to have the final data in 3 different chunks of years
           .packages = c("spam","doParallel","foreach","ncdf4","dplyr", "randomForest")) %dopar% {
             
             period <- time_period[p]
             print(period)
             
             if (period == "a") {
               
               # Loading NCs
               nc1 <- nc_open(paste0("/scratch/general/vast/u6055107/climava_nw/prism_expanding/prism_nw_expand_",var,"_19810101_19851231.nc"))        
               nc2 <- nc_open(paste0("/scratch/general/vast/u6055107/climava_nw/prism_expanding/prism_nw_expand_",var,"_19860101_19901231.nc"))        
               nc3 <- nc_open(paste0("/scratch/general/vast/u6055107/climava_nw/prism_expanding/prism_nw_expand_",var,"_19910101_19951231.nc"))
               nc4 <- nc_open(paste0("/scratch/general/vast/u6055107/climava_nw/prism_expanding/prism_nw_expand_",var,"_19960101_20001231.nc"))
               
               # Combining files      
               data <- abind(
                 ncvar_get(nc1, var),
                 ncvar_get(nc2, var),ncvar_get(nc3, var),ncvar_get(nc4, var),along = 3)
             }
             if (period == "b") {
               
               # Loading NCs
               nc1 <- nc_open(paste0("/scratch/general/vast/u6055107/climava_nw/prism_expanding/prism_nw_expand_",var,"_20010101_20051231.nc")) 
               nc2 <- nc_open(paste0("/scratch/general/vast/u6055107/climava_nw/prism_expanding/prism_nw_expand_",var,"_20060101_20101231.nc"))        
               nc3 <- nc_open(paste0("/scratch/general/vast/u6055107/climava_nw/prism_expanding/prism_nw_expand_",var,"_20110101_20151231.nc")) 
               nc4 <- nc_open(paste0("/scratch/general/vast/u6055107/climava_nw/prism_expanding/prism_nw_expand_",var,"_20160101_20201231.nc")) 
               
               # Combining files      
               data <- abind(
                 ncvar_get(nc1, var),
                 ncvar_get(nc2, var),ncvar_get(nc3, var),ncvar_get(nc4, var),along = 3)
             }
             
             
             if (period == "c") {
               
               # Loading NCs
               nc1 <- nc_open(paste0("/scratch/general/vast/u6055107/climava_nw/prism_expanding/prism_nw_expand_",var,"_20210101_20231231.nc")) 
              
               # Combining files      
               data <- ncvar_get(nc1, var)
               }
             
             
             #directory for the output data
             if (period == "a"){
               nc_out_name <- paste0("/scratch/general/vast/u6055107/climava_nw/prism_stacked_expanded/prism_nw_",var,"_19810101_20001231.nc")
             }
             
             if (period == "b"){
               nc_out_name <- paste0("/scratch/general/vast/u6055107/climava_nw/prism_stacked_expanded/prism_nw_",var,"_20010101_20201231.nc")
             }
             
             if (period == "c"){
               nc_out_name <- paste0("/scratch/general/vast/u6055107/climava_nw/prism_stacked_expanded/prism_nw_",var,"_20210101_20231231.nc")
             }
             
             # Defining dimension values
             lon <- ncvar_get(nc1, "lon")
             lat <- ncvar_get(nc1, "lat")
             if (period %in% c("a","b")){
               time <- seq(1,7305,by=1)
               } else {time <- seq(1,1095,by=1)}
             
             
             # Defining dimensions size
             LON_n <- length(unique(lon)) 
             LAT_n <- length(unique(lat))
             if (period %in% c("a","b")){
               TIME_n <- 7305
             } else {TIME_n <- 1095}
             
             #creating the Array
             combined_array <-  array(data, dim = c(LON_n, LAT_n, TIME_n))
             
             # Dimension names
             dim_name <- variables[v,3]
             dim_long_name <- variables[v,5]
             dim_units <- variables[v,7]
             
             ##defining dimensions
             lon_dim <- ncdim_def("lon", units = "degrees_east", longname = "Longitude", vals = lon)
             lat_dim <- ncdim_def("lat", units = "degrees_north", longname = "Latitude", vals = lat)
             
             if (period == "a"){
               time_dim <- ncdim_def("time", units = "days", longname = "days since 19810101", vals = time)
             }
             
             if (period == "b"){
               time_dim <- ncdim_def("time", units = "days", longname = "days since 20010101", vals = time)
             }
             
             if (period == "c"){
               time_dim <- ncdim_def("time", units = "days", longname = "days since 20210101", vals = time)
             }
             
             variable_dim <- ncvar_def(name = dim_name, units = dim_units, list(lon_dim, lat_dim, time_dim),
                                       missval =  NA,longname = dim_long_name, prec = "double", compression = 9)
             
             #creating empty NetCDF
             nc_out <- nc_create(nc_out_name,variable_dim)
             #adding variable to NetCDF
             ncvar_put(nc_out, variable_dim, combined_array)
             
             nc_close(nc_out)
             rm(combined_array)
             gc()
             
           }
}


