########################################
# Author - Sajad Khoshnood
# Utah State University
# QCNR - Watershed Sciences Department
# sajad.khoshnoodmotlagh@usu.edu

# This script is used to create guide for each GCMs model.


# Load necessary libraries
library(ncdf4)
library(raster)
library(tidyterra)
library(sf)
library(sp)

# Read the models CSV file
models <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/models_2024.csv")

# Loop through each model
for (m in 1:nrow(models)) {
  model <- models[m, 1]  # Get model name
  print(model)
  realization <- models[m, 5]  # Get realization
  print(realization)
  gl <- models[m, 6]  # Get grid label
  print(gl)
  year <- models[m, 32]  # Get year
  print(year)
  
  # Open the NetCDF file for each model of GCMs
  nc1 <- nc_open(paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/tasmin/", model, "/historical/tasmin_day_", model, "_historical_", realization, "_", gl, "_", year, ".nc"))
  
  ##loading file for prism data (in case we want to create the guide based on any other nc file beyond GCMs files)
  nc1 <- nc_open("/scratch/general/vast/u6055107/climava_nw/prism_subset_stacked _Days/prism_nw_pr_20210101_20231231.nc")
  # Create spatial points based on the resolution of each model
  ###########################################################
  
  lon <- ncvar_get(nc1, "lon")  # Get longitude values
  lat <- ncvar_get(nc1, "lat")  # Get latitude values
  grid <- expand.grid(lon = lon, lat = lat)  # Create a grid of lon and lat
  grid$lon <- ifelse(grid$lon > 180, -(360 - lon), lon)  # Adjust longitude values
  df_coord <- as.data.frame(grid)  # Convert grid to data frame
  spdf <- st_as_sf(df_coord, coords = c("lon", "lat"), crs = "NAD83")  # Convert to spatial points data frame
  
  # Extract coordinates and add them as columns to the sf object
  spdf <- spdf %>%
    mutate(lon = st_coordinates(.)[, 1],
           lat = st_coordinates(.)[, 2])
  
  # Save the spatial points data frame as a shapefile for each model
  st_write(spdf, paste0("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/guides/", model, "_guide.shp"), overwrite = TRUE)
}







