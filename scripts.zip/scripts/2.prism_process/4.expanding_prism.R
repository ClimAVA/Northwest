########################################
# Author - Andre Moraes
# Updated by Sajad Khoshnood
# Utah State University
# QCNR - Watershed Sciences Department
# andre.moraes@usu.edu & sajad.khoshnoodmotlagh@usu.edu

#this script has the purpose of expanding created subset prism to have some extra rows and columns for future process in particular about pixels located on edges of border 

#loading required packages
library(abind)
library(ncdf4)
library(dplyr)
library(randomForest)
library(Metrics)
library(doParallel)
library(spam)
library(foreign)
library(RNetCDF)
library(magrittr)

#loading necessary file to run the loops
vars <- c("pr", "tasmax", "tasmin")
variables <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/Variables.csv")
exp_guide <- read.dbf("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/guides/prism_nw_master_guide.dbf")

#different chunk years created from stacking process
time_period <- c("19810101_19851231","19860101_19901231","19910101_19951231","19960101_20001231","20010101_20051231","20060101_20101231","20110101_20151231",
                 "20160101_20201231","20210101_20231231")


#asking for the number of cores to run the code
registerDoParallel(27)

# v=1
# t=9
for (v in 1:3) {#1:3 go through all 3 variables
  var <- vars[v]
  print(var)
  for (t in 1:9) {#1:9 go through all 9 different chunks of years
    period <- time_period[t]
    print(period)
    
    #loading the created stack nc file from stacking step
    nc1 <- nc_open(paste0("/scratch/general/vast/u6055107/climava_nw/prism_subset_stacked _Days/prism_nw_",var,"_",period,".nc"))
    
    #extracting dimensions and resolutions
    lon <- unique(ncvar_get(nc1, "lon")) 
    lon_res <- abs(lon[1] - lon[2])
    lat_lenght <- length(ncvar_get(nc1, "lat"))
    lat <- unique(ncvar_get(nc1, "lat"))
    lat_res <- abs(lat[1] - lat[2])
    
    #extracting variable
    array <- ncvar_get(nc1, var)
    
    #loop through every pixel of the exp_guide
    #p=56836
    data <- foreach (p = 1:length(exp_guide$lon), .combine=cbind, .multicombine = T, .packages = c("ncdf4")) %dopar% {  
      print(p)
      guide_lon <- exp_guide[p,3] # get central coordinates (lon flip)
      guide_lat <- exp_guide[p,4] # get central coordinates
      
      X <- round((guide_lon - -125) / lon_res,0)+1 # finding central coordinate in prism nc coordinates
      Y <- as.double(round(lat_lenght - (guide_lat - tail(lat,1))/lat_res)) # finding central coordinate in prism nc coordinates
      
      # Determining if pixel should be NA (-9999) or a value
      in_out = exp_guide[p,2]
      
      #different conditions and the numbers are the number of days of each chunk year
      if(in_out == 0  & period %in% time_period[c(1:3,5:7)]){pixel =rep(NA, 1826)}
      if(in_out == 0  & period %in% time_period[c(4,8)]){pixel =rep(NA, 1827)}
      if(in_out == 0  & period %in% time_period[9]){pixel =rep(NA, 1095)}
      
      if (in_out == 1& period %in% time_period[c(1:3,5:7)]) {pixel <- round(array[X,Y,1:1826],1)}
      if (in_out == 1& period %in% time_period[c(4,8)]) {pixel <- round(array[X,Y,1:1827],1)}
      if (in_out == 1& period %in% time_period[9]) {pixel <- round(array[X,Y,1:1095],1)}
      
      cbind(pixel)
    }  
    
    # creating NetCDF
    print("creating NetCDF")
    print(Sys.time())
    
    data <- as.data.frame(data)
    rownames(data) <- as.character(1:length(data$pixel))#naming rows
    colnames(data) <- as.character(1:length(data))#naming column
    data <- t(data)#transposing data
    
    #defining dimensions for the array
    LON_n <- length(unique(exp_guide$lon)) 
    LAT_n <- length(unique(exp_guide$lat))
    if(period %in% time_period[c(1:3,5:7)]){TIME_n <- 1826}
    if(period %in% time_period[c(4,8)]){TIME_n <- 1827}
    if(period == time_period[9]){TIME_n <- 1095}
    
    
    #creating the Array
    data_array <-  array(data, dim = c(LON_n, LAT_n, TIME_n))
    
    
    #setting the directory to save the outputs
    nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/prism_expanding/prism_nw_expand_",var,"_",period,".nc")
    
    #naming dimension
    dim_name <- variables[v,3]
    dim_long_name <- variables[v,5]
    dim_units <- variables[v,7]
    
    ##defining dimensions
    lon_dim <- ncdim_def("lon", units = "degrees_east", longname = "Longitude", vals = unique(exp_guide$lon))
    lat_dim <- ncdim_def("lat", units = "degrees_north", longname = "Latitude", vals = unique(exp_guide$lat))
    time_dim <- ncdim_def("time", units = "days", longname = paste0("days since",substr(period,1,4)) , vals = seq(1,length(ncvar_get(nc1,"time")),1))
    
    #defining variable
    variable_dim <- ncvar_def(name = dim_name, units = dim_units, list(lon_dim, lat_dim, time_dim),
                              missval =  NA,longname = dim_long_name, prec = "double", compression = 9)
    #creating empty NetCDF
    nc_out <- nc_create(nc_name,variable_dim)
    
    #adding variable to NetCDF
    ncvar_put(nc_out, variable_dim, data_array)
    
    #adding global metadata to NetCDF
    ncatt_put(nc_out, 0, "Name", "prism NetCDF","character")
    ncatt_put(nc_out, 0, "Version", "NA")
    ncatt_put(nc_out, 0, "Author", "Sajad Khoshnood Motlagh & Andre Geraldo de Lima Moraes","character")
    ncatt_put(nc_out, 0, "Institution", "Utah State University, Watershed Sciences Department","character")
    ncatt_put(nc_out, 0, "Adress", "5210 Old Main Hill, NR 210, Logan, UT 84322","character")
    ncatt_put(nc_out, 0, "email", "andre.moraes@usu.edu","character")
    ncatt_put(nc_out, 0, "Description", "This is the same as the prism data, but in NetCDF format and expanded NA data","character")
    ncatt_put(nc_out, 0, "lineage", "Parameter-elevation Relationships on Independent The Slopes Model (PRISM 4K) project (https://prism.oregonstate.edu/)", "character")
    ncatt_put(nc_out, 0, "License", "Same as PRISM","character")
    ncatt_put(nc_out, 0, "fees", "This data set is free","character")
    ncatt_put(nc_out, 0, "Disclaimer", "While every effort has been made to ensure the accuracy and completeness of the data, no guarantee is given that the information provided is error-free or that the dataset will be suitable for any particular purpose. Users are advised to use this dataset with caution and to independently verify the data before making any decisions based on it. The creators of this dataset make no warranties, express or implied, regarding the dataset's accuracy, reliability, or fitness for a particular purpose. In no event shall the creators be liable for any damages, including but not limited to direct, indirect, incidental, special, or consequential damages, arising out of the use or inability to use the dataset. Users of this dataset are encouraged to properly cite the dataset in any publications or works that make use of the data. By using this dataset, you agree to these terms and conditions. If you do not agree with these terms, please do not use the dataset.","character")
    
    #closing NetCDF
    nc_close(nc_out)
    rm(data_array)
    gc()
    
  }
}

