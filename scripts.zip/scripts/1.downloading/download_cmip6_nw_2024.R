########################################
# Author - Andre Moraes
# Updated by Sajad Khoshnood
# Utah State University
# QCNR - Watershed Sciences Department
# andre.moraes@usu.edu & sajad.khoshnoodmotlagh@usu.edu

# This script is used to download historical and future data of 17 GCMs models (CMIP6) for the northwest of the US.

################################################################
# 
# Tree data frames were built in preparation for this script to run.
# - the models data frame contains almost all information necessary to build the
# URLs to download the files through HTTP download
# - the historical and future data frames have the initial and final dates for 
# each file for each model
# 
################################################################

#loading guide data frames
future_dates <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/cmpi6_2024_dowloading/future_dates_2024.csv") # all dates for ssp245
historical_dates <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/cmpi6_2024_dowloading/historical_dates_2024.csv") # all dates for historical
models <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/cmpi6_2024_dowloading/models_2024.csv") #has all the other information necessary to create the HTTPs
ssps <- c("historical","ssp245","ssp370","ssp585")
vars <- c("pr", "tasmax", "tasmin")

# changing timeout for  downloads
getOption("timeout")
options(timeout = 10000)

#########################################################################
# #####Creating directories--------
# getwd()
# setwd("/scratch/general/vast/u6055107/cmip6_2024_downloading") # setting the directory to create folders and save the data
# for (i in 1:3){
#    v = vars[i]
#    dir.create(v)
# }
#  for (i in 1:3){
#    v = vars[i]
#    for (m in 1:25){
#      model = models[m,1]
#      dir = paste0(v,"/",model)
#      dir.create(dir)
#   }
# }
# #
# for (i in 1:3){
#   v = vars[i]
#   for (m in 1:25){
#     model = models[m,1]
#     for (s in 1:4){
#       ssp = ssps[s]
#       dir = paste0(v,"/",model,"/",ssp)
#       dir.create(dir)
#     }
#   }
# }
####################################################################
# i=2
# s=1
# m=13
for (i in 1:3){ #three variables
  var = vars[i]
  
  for (m in 1:17){ #1:17 number of GCMs models
    ## taking some information of each model based on models.csv file
    inst_id_hist = models[m,3]
    inst_id_ssp = models[m,4]
    model = models[m,1]
    realization = models[m,5]
    grid = models[m,6]
    node = models[m,22]
    dataroot_hist = models[m,23]
    dataroot_ssp = models[m,24]
    path_hist = models[m,25]
    path_ssp = models[m,26]
    
    for (s in 1:4){ # four different climate scenario
      ssp = ssps[s]
      
      if(ssp == "historical" & (var == "tasmax" | var == "tasmin")) {dates_n = models[m,7]} # number of files
      if(ssp == "historical" & var == "pr") {dates_n = models[m,8]}
      if(ssp == "ssp245") {dates_n = models[m,9]}
      if(ssp == "ssp370") {dates_n = models[m,9]}
      if(ssp == "ssp585") {dates_n = models[m,9]}
      
      if(ssp == "historical" & (m %in% c(1:17))& (var == "tasmax" | var == "tasmin")) {dates = historical_dates[1:dates_n,m]}# creating a vector of the dates
      if(ssp == "historical" & (m %in% c(10,13)) & var == "pr") {dates = historical_dates[2:3,m]}  # use this because the number of files for pr are 2 and are different from tasmax and tasmin
      if(ssp == "ssp245"|ssp == "ssp370"|ssp == "ssp585") {dates = future_dates[1:dates_n,m]}
      
      
      if(ssp == "historical") {vv = c(10,14,18)} # columns where the versions are 
      if(ssp == "ssp245") {vv = c(11,15,19)}
      if(ssp == "ssp370") {vv = c(12,16,20)}
      if(ssp == "ssp585") {vv = c(13,17,21)}
      
      if(var == "pr") {vvv = vv[1]}
      if(var == "tasmax") {vvv = vv[2]}
      if(var == "tasmin") {vvv = vv[3]}
      
      version = models[m,vvv]
      version <- paste0("v",version)
      
      for (d in 1:length(dates)){
        date = dates[d]
        
        if(ssp == "historical"){  #setting url if ssp is for historical data
          
          url <- paste0("http://",node,"/thredds/fileServer/",dataroot_hist,"/",path_hist,"/",inst_id_hist,"/",model,"/",ssp,"/",realization,"/day/",var,"/",grid,"/",version,"/",var,"_day_",model,"_",ssp,"_",realization,"_",grid,"_",date,".nc")
          destfile <- paste0("/scratch/general/vast/u6055107/cmip6_2024_downloading_nw/",var,"/",model,"/",ssp,"/",var,"_day_",model,"_",ssp,"_",realization,"_",grid,"_",date,".nc")  ## this is the directory to save the downloaded data
          tem <- file.exists(destfile)
          print(destfile)
          print(tem)
          
          if(tem == FALSE){  # if we have the file no need to download it again
            download.file(url, destfile, mode = "wb")
          }
        }
        if(ssp == "ssp245" |ssp == "ssp370" |ssp == "ssp585"){
          
          url <- paste0("http://",node,"/thredds/fileServer/",dataroot_ssp,"/",path_ssp,"/",inst_id_ssp,"/",model,"/",ssp,"/",realization,"/day/",var,"/",grid,"/",version,"/",var,"_day_",model,"_",ssp,"_",realization,"_",grid,"_",date,".nc")
          destfile <- paste0("/scratch/general/vast/u6055107/cmip6_2024_downloading_nw/",var,"/",model,"/",ssp,"/",var,"_day_",model,"_",ssp,"_",realization,"_",grid,"_",date,".nc")
          tem <- file.exists(destfile)
          print(destfile)
          print(tem)
          
          if(tem == FALSE){
            download.file(url, destfile, mode = "wb")
          }
        }        
      }               
    }
  }
}



# Fim










