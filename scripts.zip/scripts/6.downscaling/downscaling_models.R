#########################################
# Author - Andre Moraes
# Utah State University
# QCNR - Watershed Sciences Department
# andre.moraes@usu.edu
#
# This script is used to for downscaling GCM data
################################################################

#packages
library(ncdf4)
library(dplyr)
library(randomForest)
library(Metrics)
library(doParallel)
library(spam)
library(foreign)

#loading data frames used to guide the process
models <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/models_2024.csv") #has all the other information necessary to create the HTTPs
variables <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/Variables.csv")
grid <- read.dbf("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/guides/original_prism_guide.dbf") # loading prism guide
grid<-grid[,c(4,3,1,2)] #reordering columns
vars <- c("pr", "tasmax", "tasmin")
ssps <- c("historical","ssp245","ssp370","ssp585")
#########################################################################
#####Creating directories--------

# getwd()
# setwd("/scratch/general/vast/u6055107/climava_nw/hist_future_downscaling")
# 
# for (m in 1:17){
#   model = models[m,1]
#   dir.create(model)
# 
#   for (s in 1:4) {
#     ssp <- ssps[s]
#     print(ssp)
# 
#     dir <- paste0(model,"/",ssp)
# 
#     dir.create(dir)
# 
#     for (v in 1:3){
#       var <- vars[v]
#       print(var)
# 
#       dir1 <- paste0(model,"/",ssp,"/",var)
# 
#       dir.create(dir1)
#   }
#  }
# }

####################################################################
# v=1
# s=1
# m=1
for (v in 1:3){# loop trough variables
  
  var <- paste(variables[v,3])
  print(var)
  
  for (s in 1:4){ # loop through scenarios
    
    ssp = ssps[s]
    print(ssp)
    
    #loading guides with files start and end date and other information
    if(ssp == "historical") {files <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/files_DS_hist.csv")}
    if(ssp == "ssp245"|ssp == "ssp370"|ssp == "ssp585") {files <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/files_DS_future.csv")}
    
    # loop trough models
    for(m in 1:17) { 
      
      model = models[m,1]
      print(model)
      realization <- models[m,5]
      
      #asking for some information to run the process through loops
      if(var == "pr" & ssp == "historical") {version = models[m,10]}
      if(var == "pr" & ssp == "ssp245") {version = models[m,11]}
      if(var == "pr" & ssp == "ssp370") {version = models[m,12]}
      if(var == "pr" & ssp == "ssp485") {version = models[m,13]}
      
      if(var == "tasmax" & ssp == "historical") {version = models[m,14]}
      if(var == "tasmax" & ssp == "ssp245") {version = models[m,15]}
      if(var == "tasmax" & ssp == "ssp370") {version = models[m,16]}
      if(var == "tasmax" & ssp == "ssp485") {version = models[m,17]}
      
      if(var == "tasmin" & ssp == "historical") {version = models[m,18]}
      if(var == "tasmin" & ssp == "ssp245") {version = models[m,19]}
      if(var == "tasmin" & ssp == "ssp370") {version = models[m,20]}
      if(var == "tasmin" & ssp == "ssp485") {version = models[m,21]}
      
      
      guide <- read.dbf(paste0("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/guides/",model,"_guide.dbf")) # loading guide for each model
      guide$lon1 <- ifelse(guide$lon < 0, (360 + guide$lon), guide&lon) # convert lon values in negtive side if needed
      guide <- guide[,c(4,1:2,5,3)] #reordering columns
      
      guide_lat_res <- models[m,27] #taking lat resolution of each model based on models file
      guide_lon_res <- models[m,28] #taking lon resolution of each model based on models file
      guide_lat_length <- length(unique(guide$lat))
      guide_lon_length <- length(unique(guide$lon))
      guide_lat <- unique(guide$lat)
      left <- min(guide$lon) # Get the leftmost longitude for each model
      
      
      # loading bias corrected data  
      if (var == "tasmin" | var == "tasmax"){nc_bc <- nc_open(paste0("/scratch/general/vast/u6055107/climava_nw/bias_correction/",ssp,"_",var,"_day_",model,"_EDCDFm.nc"))}
      if (var == "pr"){nc_bc <- nc_open(paste0("/scratch/general/vast/u6055107/climava_nw/bias_correction/",ssp,"_",var,"_day_",model,"_BC.nc"))}
      bc_array <- ncvar_get(nc_bc, var)
      rm(nc_bc) 
      #f=1
      # loop through each file to be created
      for (f in 1: length(files[,1])){
        #getting some information for the number of days and and starting and fishing year
        dates <- files[f,5]
        start <- files[f,3]
        finish <- files[f,4]
        length_1 <- files[f,2]
        SD <- files[f,6]
        start_time <- print(Sys.time())   
        print(dates)
        
        
        data_since <- as.numeric(substr(dates,1,8))  # to take the first date of staring date for each period
        
        
        
        # defining the name of the file                                                                                                                                                                                        
        nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/hist_future_downscaling/",model,"/",ssp,"/",var,"/ClimAVA-NW_",model,"_",ssp,"_",var,"_",realization,"_",dates,".nc")
        
        # testing if file was already created
        tem <- file.exists(nc_name)
        print(tem)
        
        if (tem == FALSE){
          
          ############################################################################################################
          #i=42
          
          # defining dopar parameters  
          registerDoParallel(14)
          
          # downscaling is done for each pixel
          data <- foreach (i =1:length(grid$id),
                           .packages = c("spam","doParallel","foreach","ncdf4","dplyr", "randomForest", "Metrics")) %dopar% {
                             
                             #identifying pixels located out or in of the border
                             IN_OUT <- grid[i,2] 
                             
                             if (IN_OUT == 0){
                               
                               pixel <- rep(NA, length_1)
                               
                             }
                             
                             if (IN_OUT == 1){
                               
                               ID = i
                               print(ID)
                               # loading trained pixels
                               model_name <- paste0("/scratch/general/vast/u6055107/climava_nw/downscaling_validation/rf_all_models/",model,"/",var,"/rf_",ID,"_",model,"_",var,".rds")
                               
                               
                               tem <- file.exists(model_name)
                               print(tem)
                               
                               if (tem == TRUE){
                                 
                                 grid_lon = grid[i,3] #taking lon for each pixel
                                 grid_lat = grid[i,4] #taking lat for each pixel
                                 
                                 
                                 dist <- guide
                                 #this used to identify the closest pixel 
                                 dist$dist <- sqrt((dist$lon-grid_lon)^2+(dist$lat-grid_lat)^2)
                                 row <- dist[which.min(dist$dist),]
                                 
                                 # This all X and Y specifies how the method model should pass through the 9 pixels surrounding the first pixel.
                                 X1 <- row[1,2] #lon
                                 Y1 <- row[1,3] #lat
                                 X2 <- row[1,2]
                                 Y2 <- row[1,3] - guide_lat_res
                                 X3 <- row[1,2] + guide_lat_res
                                 Y3 <- row[1,3] - guide_lat_res
                                 X4 <- row[1,2] + guide_lat_res
                                 Y4 <- row[1,3]
                                 X5 <- row[1,2] + guide_lat_res
                                 Y5 <- row[1,3] + guide_lat_res
                                 X6 <- row[1,2]
                                 Y6 <- row[1,3] + guide_lat_res
                                 X7 <- row[1,2] - guide_lat_res
                                 Y7 <- row[1,3] + guide_lat_res
                                 X8 <- row[1,2] - guide_lat_res
                                 Y8 <- row[1,3]
                                 X9 <- row[1,2] - guide_lat_res
                                 Y9 <- row[1,3] - guide_lat_res
                                 
                                 
                                 # finding exact array position for each of the 9 pixels
                                 #cov_1:9 > taking the values based on each pixel position for the whole period
                                 #1
                                 
                                 X_1 <- round((X1 - left) / guide_lon_res,0) + 1 
                                 Y_1 <- as.double(round(guide_lat_length - abs((Y1 - tail(guide_lat,1))/guide_lat_res)))
                                 
                                 cov_1 <- bc_array[X_1,Y_1,start:finish]
                                 
                                 #2
                                 
                                 X_2 <- round((X2 - left) / guide_lon_res,0) + 1 
                                 Y_2 <- as.double(round(guide_lat_length - abs((Y2 - tail(guide_lat,1))/guide_lat_res)))
                                 
                                 cov_2 <- bc_array[X_2,Y_2,start:finish]
                                 
                                 #3
                                 
                                 X_3 <- round((X3 - left) / guide_lon_res,0) + 1 
                                 Y_3 <- as.double(round(guide_lat_length - abs((Y3 - tail(guide_lat,1))/guide_lat_res)))
                                 
                                 cov_3 <- bc_array[X_3,Y_3,start:finish]
                                 
                                 #4
                                 
                                 X_4 <- round((X4 - left) / guide_lon_res,0) + 1 
                                 Y_4 <- as.double(round(guide_lat_length - abs((Y4 - tail(guide_lat,1))/guide_lat_res)))
                                 
                                 cov_4 <- bc_array[X_4,Y_4,start:finish]
                                 
                                 #5
                                 
                                 X_5 <- round((X5 - left) / guide_lon_res,0) + 1 
                                 Y_5 <- as.double(round(guide_lat_length - abs((Y5 - tail(guide_lat,1))/guide_lat_res)))
                                 
                                 cov_5 <- bc_array[X_5,Y_5,start:finish]
                                 
                                 #6
                                 
                                 X_6 <- round((X6 - left) / guide_lon_res,0) + 1 
                                 Y_6 <- as.double(round(guide_lat_length - abs((Y6 - tail(guide_lat,1))/guide_lat_res)))
                                 
                                 cov_6 <- bc_array[X_6,Y_6,start:finish]
                                 
                                 #7
                                 
                                 X_7 <- round((X7 - left) / guide_lon_res,0) + 1 
                                 Y_7 <- as.double(round(guide_lat_length - abs((Y7 - tail(guide_lat,1))/guide_lat_res)))
                                 
                                 cov_7 <- bc_array[X_7,Y_7,start:finish]
                                 
                                 #8
                                 
                                 X_8 <- round((X8 - left) / guide_lon_res,0) + 1 
                                 Y_8 <- as.double(round(guide_lat_length - abs((Y8 - tail(guide_lat,1))/guide_lat_res)))
                                 
                                 cov_8 <- bc_array[X_8,Y_8,start:finish]
                                 
                                 #9
                                 
                                 X_9 <- round((X9 - left) / guide_lon_res,0) + 1 
                                 Y_9 <- as.double(round(guide_lat_length - abs((Y9- tail(guide_lat,1))/guide_lat_res)))
                                 
                                 cov_9 <- bc_array[X_9,Y_9,start:finish]
                                 
                                 
                                 # creating a data frame depending variable and adding independent variables to it
                                 cal <- as.data.frame(cov_1) # this cal is the observed data
                                 
                                 cal$cov_1 <- cov_1
                                 cal$cov_2 <- cov_2
                                 cal$cov_3 <- cov_3
                                 cal$cov_4 <- cov_4
                                 cal$cov_5 <- cov_5
                                 cal$cov_6 <- cov_6
                                 cal$cov_7 <- cov_7
                                 cal$cov_8 <- cov_8
                                 cal$cov_9 <- cov_9
                                 
                                 cal <- cal[, colSums(is.na(cal)) == 0]
                                 
                                 #read the trained model from the previous process and predict the value base on
                                 rf <- readRDS(model_name)
                                 pred <- predict(rf,cal)
                                 if (var == "pr"){ #to have not negative value for pr
                                   pred[pred <= 0] <- 0
                                 }
                                 
                                 pixel <- as.vector(round(pred,1))
                                 
                                 rm(rf, grid_lon, grid_lat, dist, row, cov_1, cov_2, cov_3, cov_4, cov_5, cov_6, cov_7, cov_8, cov_9, cal)
                                 gc()
                               }
                             }
                             cbind(pixel)
                             
                           }
          # creating NetCDF
          data <- as.data.frame(data)
          rownames(data) <- as.character(1:length(data[,1]))
          colnames(data) <- as.character(1:length(data))
          data <- t(data)
          
          # defining dimensions
          LON_n <- length(unique(grid$lon)) 
          LAT_n <- length(unique(grid$lat))
          TIME_n <- length_1 
          
          # creating array
          data_array <-  array(data, dim = c(LON_n, LAT_n, TIME_n))
          
          # naming dimensions
          dim_name <- variables[v,3]
          dim_long_name <- variables[v,5]
          dim_units <- variables[v,7]
          dim_standard_name <- variables[v,8]
          
          # defining dimensions
          lon_dim <- ncdim_def("lon", units = "degrees_east", longname = "Longitude", vals = unique(grid$lon))
          lat_dim <- ncdim_def("lat", units = "degrees_north", longname = "Latitude", vals = unique(grid$lat))
          time_dim <- ncdim_def("time", units = "days", longname = paste0("days since start ",data_since), vals = seq(1,length_1,1))
          
          # variable dimensions
          variable_dim <- ncvar_def(name = dim_name, units = dim_units, list(lon_dim, lat_dim, time_dim),
                                    missval =  NA,longname = dim_long_name, prec = "double", compression = 9)
          
          # creating empty NetCDF 
          nc_out <- nc_create(nc_name,variable_dim)
          
          # adding variable to NetCDF
          ncvar_put(nc_out, variable_dim, data_array)
          
          #adding global metadata to NetCDF
          ncatt_put(nc_out, var, "standard_name", dim_standard_name)
          ncatt_put(nc_out, 0, "Name", "Clinate data for Adaptation and Vulnerability Assesments - Northwest (ClimAVA-NW)","character") 
          ncatt_put(nc_out, 0, "Version", "1.0")
          ncatt_put(nc_out, 0, "Creation date", paste0(Sys.time()),"character")
          ncatt_put(nc_out, 0, "Author", "Andre Geraldo de Lima Moraes & Sajad Khoshnood Motlagh","character")
          ncatt_put(nc_out, 0, "Institution", "Utah State University, Watershed Sciences Department","character")
          ncatt_put(nc_out, 0, "Adress", "5210 Old Main Hill, NR 210, Logan, UT 84322","character")
          ncatt_put(nc_out, 0, "email", "andre.moraes@usu.edu & sajad.khoshnoodmotlagh@usu.edu","character")
          ncatt_put(nc_out, 0, "Description", "The ClimAVA-NW dataset provides a high-resolution (4km) bias-corrected, downscaled future climate projection based on seventeen CMIP6 GCMs. The dataset includes three variables (pr, tasmin, tasmax) and three Shared Socio-economic Pathways (SSP245, SSP370, SSP585) for the entire U.S.Nouthwest region. ClimAVA-NW employs the Spatial Pattern Interaction Downscaling (SPID) method which applies Random Forest model to translate the relationship and intercations between spatial patterns at a coarse resolution and fine-resolution pixel values. A random forest model is trained for each pixel, with the finer pixel of the reference data as the predictor and nine pixels from the spatially resampled (coarser) version of the reference data (at the GCMs spatial resolution) as predictors. Models are then used to downscale the GCM data. See the pepper describing the method and data set for more information.","character")
          ncatt_put(nc_out, 0, "lineage", paste0("ClimaAVA uses the Parameter-elevation Relationships on Independent The Slopes Model (PRISM 4K) project (https://prism.oregonstate.edu/) as reference data for both bias correction and the training of downscaling models. This file contain data downscaled from model",model," SSP ",ssp," variant label ",realization,", version ",version),"character")
          ncatt_put(nc_out, 0, "License", "CCO 1.0 Universal","character")
          ncatt_put(nc_out, 0, "fees", "This data set is free","character")
          ncatt_put(nc_out, 0, "Disclaimer", "While every effort has been made to ensure the accuracy and completeness of the data, no guarantee is given that the information provided is error-free or that the dataset will be suitable for any particular purpose. Users are advised to use this dataset with caution and to independently verify the data before making any decisions based on it. The creators of this dataset make no warranties, express or implied, regarding the dataset's accuracy, reliability, or fitness for a particular purpose. In no event shall the creators be liable for any damages, including but not limited to direct, indirect, incidental, special, or consequential damages, arising out of the use or inability to use the dataset. Users of this dataset are encouraged to properly cite the dataset in any publications or works that make use of the data. By using this dataset, you agree to these terms and conditions. If you do not agree with these terms, please do not use the dataset.","character")
         
          # closing NetCDF
          nc_close(nc_out)
          
          time_difference <- print((Sys.time()) -start_time)
          print(paste0(model,"/",var,"/",ssp," is finished"))
          
          rm(data, lon_dim, lat_dim,time_dim, variable_dim, nc_out)
          
          gc()
          } 
        }
      }
    }  
}

