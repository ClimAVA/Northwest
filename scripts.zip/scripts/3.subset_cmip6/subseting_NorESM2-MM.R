########################################
# Author - Andre Moraes
# Updated by Sajad Khoshnood
# Utah State University
# QCNR - Watershed Sciences Department
# andre.moraes@usu.edu & sajad.khoshnoodmotlagh@usu.edu

# This script is used to subset cmip6 models.
############ NorESM2-MM ####################

# Load the necessary data files
future_dates <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/future_dates_2024.csv") # all dates for future
historical_dates <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/historical_dates_2024.csv") # all dates for historical
models <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/models_2024.csv") # contains model metadata
variables <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/Variables.csv") # variable definitions
ssps <- c("historical", "ssp245", "ssp370", "ssp585") # scenarios

# Defining the sequence of days
historical_days <- seq(1, 12410, 1) # Historical days sequence
ssp_days <- seq(12411, 43800, 1)    # Future days sequence

# Loading necessary libraries
library(ncdf4)   # NetCDF library for reading and writing data
library(dplyr)   # Data manipulation library
library(foreign) # Library for reading .dbf files

#########################################################################
# getwd()
# setwd("/scratch/general/vast/u6047395/cmip6/cmip6_subset")

# for (m in 1:17) {
#   model = models[m,1]
#   dir.create(model)  # Create directory for each model
# }
# 
# for (m in 1:17) {
#   model = models[m,1]
#   for (s in 1:4) {
#     ssp = ssps[s]
#     dir = paste0(model, "/", ssp)
#     dir.create(dir)  # Create subdirectory for each scenario
#   }
# }
# 
# for (m in 1:17) {
#   model = models[m,1]
#   for (s in 1:4) {
#     ssp = ssps[s]
#     for (i in 1:3) {
#       v = vars[i]
#       dir = paste0(model, "/", ssp, "/", v)
#       dir.create(dir)  # Create subdirectory for each variable
#     }
#   }
# }
##########################################################################
####### Subsetting Model: m = 8 #########################################
#######################################################################

# Model-specific information
lon_res <- 360 / 288  ###### Change for every model
lat_res <- 180 / 192  ###### Change for every model

m = 8  # Model index for NorESM2-MM
model = models[m, 1]  # Model name
realization = models[m, 5]  # Realization (ensemble member)
grid = models[m, 6]  # Grid information

guide <- read.dbf(paste0("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/guides/", model, "_guide.dbf"))  # Read guide file with coordinates
guide$lon1 <- ifelse(guide$lon < 0, (360 + guide$lon), guide$lon)  # Adjust longitude if negative

guide <- guide[, c(4, 1:2, 5, 3)]  # Select relevant columns from guide

# Loop through SSPS (historical, ssp245, ssp370, ssp585)
for (s in 1:4) {
  ssp = ssps[s]  # Scenario
  print(ssp)
  
  # Set the number of files depending on the scenario
  if (ssp == "historical") {
    dates_n = models[m, 7]  # number of historical files
  }
  if (ssp == "ssp245" | ssp == "ssp370" | ssp == "ssp585") {
    dates_n = models[m, 9]  # number of future files
  }
  
  # Get the corresponding dates for the scenario
  if (ssp == "historical") {
    dates = historical_dates[1:dates_n, m]  # historical dates
  }
  if (ssp == "ssp245" | ssp == "ssp370" | ssp == "ssp585") {
    dates = future_dates[1:dates_n, m]  # future dates
  }
  
  # Loop through variables
  for (v in 1:3) {
    var = variables[v, 3]  # Variable name
    print(var)
    
    # Subsetting historical data
    if (ssp == "historical") {
      for (d in 1:length(dates)) {
        
        if (d == 1 | d == 2 | d == 3) {
          date = dates[d]  # Select date
          print(date)
          nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/", var, "/", model, "/", ssp, "/", var, "_day_", model, "_", ssp, "_", realization, "_", grid, "_", date, ".nc")  # NetCDF file name
          nc <- nc_open(nc_name)  # Open NetCDF file
          
          array <- ncvar_get(nc, var)  # Get the variable data from the file
          
          pixels = rep(NA, 3650)  # Initialize pixel data
          p = 1
          for (p in 1:length(guide$lon)) {  # Loop through each pixel
            in_out <- guide[p, 5]  # Check if the pixel is inside the domain
            if (in_out == 0) {
              pixel = rep(NA, 365)  # If outside the domain, set to NA
            }
            if (in_out == 1) {  # If inside the domain, extract data
              Y <- ((guide[p, 3] + 90) / lat_res) + 1  # Convert latitudes to pixel positions
              X <- (guide[p, 4] / lon_res) + 1  # Convert longitudes to pixel positions
              if (d == 1) {
                pixel <- array[X, Y, 366:3650]  # Select the relevant time range for the first day
              } else {
                pixel <- array[X, Y, 1:3650]  # Select the relevant time range for subsequent days
              }
            }
            pixels <- cbind(pixels, pixel)  # Append pixel data
          }
          
          # Store data for each date
          if (d == 1) { pixels_d1 <- pixels[, -1] }
          if (d == 2) { pixels_d2 <- pixels[, -1] }
          if (d == 3) { pixels_d3 <- pixels[, -1] }
        }
        
        if (d == 4) {
          date = dates[d]  # Select date
          print(date)
          nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/", var, "/", model, "/", ssp, "/", var, "_day_", model, "_", ssp, "_", realization, "_", grid, "_", date, ".nc")  # NetCDF file name
          nc <- nc_open(nc_name)  # Open NetCDF file
          
          array <- ncvar_get(nc, var)  # Get the variable data from the file
          
          pixels = rep(NA, 1825)  # Initialize pixel data
          p = 1
          for (p in 1:length(guide$lon)) {  # Loop through each pixel
            in_out <- guide[p, 5]  # Check if the pixel is inside the domain
            if (in_out == 0) {
              pixel = rep(NA, 365)  # If outside the domain, set to NA
            }
            if (in_out == 1) {  # If inside the domain, extract data
              Y <- ((guide[p, 3] + 90) / lat_res) + 1  # Convert latitudes to pixel positions
              X <- (guide[p, 4] / lon_res) + 1  # Convert longitudes to pixel positions
              pixel <- array[X, Y, 1:1825]  # Select the relevant time range
            }
            pixels <- cbind(pixels, pixel)  # Append pixel data
          }
          
          if (d == 4) { pixels_d4 <- pixels[, -1] }
        }
      }
      
      data <- rbind(pixels_d1, pixels_d2, pixels_d3, pixels_d4)  # Combine pixel data
      
      # Create the NetCDF file
      getwd()  # Get the current working directory
      setwd(paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_subset/", model, "/", ssp, "/", var))  # Set the working directory for output
      
      data <- as.data.frame(data)  # Convert data to a data frame
      rownames(data) <- as.character(1:length(data$pixel))  # Set row names
      colnames(data) <- as.character(1:length(data))  # Set column names
      data <- t(data)  # Transpose the data
      
      LON_n <- length(unique(guide$lon))  # Number of unique longitude values
      LAT_n <- length(unique(guide$lat))  # Number of unique latitude values
      TIME_n <- 12410  # Number of time steps
      
      data_array <- array(data, dim = c(LON_n, LAT_n, TIME_n))  # Convert data to array
      
      nc_name <- paste0(var, "_day_", model, "_", realization, "_", ssp, "_subset.nc")  # Output NetCDF file name
      dim_name <- variables[v, 3]  # Dimension name for the variable
      dim_long_name <- variables[v, 5]  # Long name for the variable
      dim_units <- variables[v, 7]  # Units for the variable
      
      # Defining dimensions for NetCDF
      lon_dim <- ncdim_def("lon", units = "degrees_east", longname = "Longitude", vals = unique(guide$lon))  # Longitude dimension
      lat_dim <- ncdim_def("lat", units = "degrees_north", longname = "Latitude", vals = unique(guide$lat))  # Latitude dimension
      time_dim <- ncdim_def("time", units = "days", longname = "days since 19810101", vals = historical_days)  # Time dimension
      
      variable_dim <- ncvar_def(name = dim_name, units = dim_units, list(lon_dim, lat_dim, time_dim),
                                missval = NA, longname = dim_long_name, prec = "double")  # Variable definition
      
      nc_out <- nc_create(nc_name, variable_dim)  # Create NetCDF file
      
      ncvar_put(nc_out, variable_dim, data_array)  # Write data to the NetCDF file
      
      nc_close(nc_out)  # Close the NetCDF file
    }
    
    ############################################################################################
    # Subsetting for future scenarios (ssp245, ssp370, ssp585)
    if (ssp == "ssp245" | ssp == "ssp370" | ssp == "ssp585") {
      d = 1
      for (d in 1:length(dates)) {
        
        if (d == 1) {
          date = dates[d]  # Select date
          print(date)
          nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/", var, "/", model, "/", ssp, "/", var, "_day_", model, "_", ssp, "_", realization, "_", grid, "_", date, ".nc")  # NetCDF file name
          nc <- nc_open(nc_name)  # Open NetCDF file
          
          array <- ncvar_get(nc, var)  # Get the variable data from the file
          
          pixels = rep(NA, 1825)  # Initialize pixel data
          p = 1
          for (p in 1:length(guide$lon)) {  # Loop through each pixel
            in_out <- guide[p, 5]  # Check if the pixel is inside the domain
            if (in_out == 0) {
              pixel = rep(NA, 365)  # If outside the domain, set to NA
            }
            if (in_out == 1) {  # If inside the domain, extract data
              Y <- ((guide[p, 3] + 90) / lat_res) + 1  # Convert latitudes to pixel positions
              X <- (guide[p, 4] / lon_res) + 1  # Convert longitudes to pixel positions
              pixel <- array[X, Y, 1:1825]  # Select the relevant time range
            }
            pixels <- cbind(pixels, pixel)  # Append pixel data
          }
          
          if (d == 1) { pixels_d1 <- pixels[, -1] }
        }
        
        # Handle the rest of the dates
        if (d == 2 | d == 3 | d == 4 | d == 5 | d == 6 | d == 7 | d == 8 | d == 9) {
          date = dates[d]  # Select date
          print(date)
          nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/", var, "/", model, "/", ssp, "/", var, "_day_", model, "_", ssp, "_", realization, "_", grid, "_", date, ".nc")  # NetCDF file name
          nc <- nc_open(nc_name)  # Open NetCDF file
          
          array <- ncvar_get(nc, var)  # Get the variable data from the file
          
          pixels = rep(NA, 3650)  # Initialize pixel data
          p = 1
          for (p in 1:length(guide$lon)) {  # Loop through each pixel
            in_out <- guide[p, 5]  # Check if the pixel is inside the domain
            if (in_out == 0) {
              pixel = rep(NA, 365)  # If outside the domain, set to NA
            }
            if (in_out == 1) {  # If inside the domain, extract data
              Y <- ((guide[p, 3] + 90) / lat_res) + 1  # Convert latitudes to pixel positions
              X <- (guide[p, 4] / lon_res) + 1  # Convert longitudes to pixel positions
              pixel <- array[X, Y, 1:3650]  # Select the relevant time range
            }
            pixels <- cbind(pixels, pixel)  # Append pixel data
          }
          
          if (d == 2) { pixels_d2 <- pixels[, -1] }
          if (d == 3) { pixels_d3 <- pixels[, -1] }
          if (d == 4) { pixels_d4 <- pixels[, -1] }
          if (d == 5) { pixels_d5 <- pixels[, -1] }
          if (d == 6) { pixels_d6 <- pixels[, -1] }
          if (d == 7) { pixels_d7 <- pixels[, -1] }
          if (d == 8) { pixels_d8 <- pixels[, -1] }
          if (d == 9) { pixels_d9 <- pixels[, -1] }
        }
      }
      
      data <- rbind(pixels_d1, pixels_d2, pixels_d3, pixels_d4, pixels_d5, pixels_d6, pixels_d7, pixels_d8, pixels_d9)  # Combine pixel data
      
      # Create the NetCDF file
      getwd()  # Get the current working directory
      setwd(paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_subset/", model, "/", ssp, "/", var))  # Set the working directory for output
      
      data <- as.data.frame(data)  # Convert data to a data frame
      rownames(data) <- as.character(1:length(data$pixel))  # Set row names
      colnames(data) <- as.character(1:length(data))  # Set column names
      data <- t(data)  # Transpose the data
      
      LON_n <- length(unique(guide$lon))  # Number of unique longitude values
      LAT_n <- length(unique(guide$lat))  # Number of unique latitude values
      TIME_n <- 4380  # Number of time steps
      
      data_array <- array(data, dim = c(LON_n, LAT_n, TIME_n))  # Convert data to array
      
      nc_name <- paste0(var, "_day_", model, "_", realization, "_", ssp, "_subset.nc")  # Output NetCDF file name
      dim_name <- variables[v, 3]  # Dimension name for the variable
      dim_long_name <- variables[v, 5]  # Long name for the variable
      dim_units <- variables[v, 7]  # Units for the variable
      
      # Defining dimensions for NetCDF
      lon_dim <- ncdim_def("lon", units = "degrees_east", longname = "Longitude", vals = unique(guide$lon))  # Longitude dimension
      lat_dim <- ncdim_def("lat", units = "degrees_north", longname = "Latitude", vals = unique(guide$lat))  # Latitude dimension
      time_dim <- ncdim_def("time", units = "days", longname = "days since 19810101", vals = ssp_days)  # Time dimension
      
      variable_dim <- ncvar_def(name = dim_name, units = dim_units, list(lon_dim, lat_dim, time_dim),
                                missval = NA, longname = dim_long_name, prec = "double")  # Variable definition
      
      nc_out <- nc_create(nc_name, variable_dim)  # Create NetCDF file
      
      ncvar_put(nc_out, variable_dim, data_array)  # Write data to the NetCDF file
      
      nc_close(nc_out)  # Close the NetCDF file
    }
  }
}
