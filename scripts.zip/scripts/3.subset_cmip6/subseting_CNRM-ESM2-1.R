########################################
# Author - Andre Moraes
# Updated by Sajad Khoshnood
# Utah State University
# QCNR - Watershed Sciences Department
# andre.moraes@usu.edu & sajad.khoshnoodmotlagh@usu.edu

# This script is used to subset cmip6 models.

############ CNRM-ESM2-1 ####################

# Load external CSV files containing information about future and historical dates,
# models, and variables for climate data processing.
future_dates <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/future_dates_2024.csv") # all dates for future scenarios
historical_dates <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/historical_dates_2024.csv") # All dates for historical
models <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/models_2024.csv") # Contains model info
variables <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/Variables.csv") # Contains variable names and metadata
ssps <- c("historical", "ssp245", "ssp370", "ssp585") # List of scenario pathways

# Define the range of days for historical and future datasets
historical_days <- seq(1, 12410, 1) # Range for historical data (days)
ssp_days <- seq(12411, 43800, 1) # Range for SSP future scenarios

# Load required R libraries
library(ncdf4) # To handle NetCDF files
library(dplyr) # For data manipulation
library(foreign) # To handle DBF files

#########################################################################
##### Creating directories for storing subsets of data -----------------
# Uncomment these blocks to create necessary directories if needed

# Create main directories for each model
# for (m in 1:17){
#   model = models[m,1]
#   dir.create(model)
# }

# Create directories for each scenario (historical, SSPs)
# for (m in 1:17){
#   model = models[m,1]
#   for (s in 1:4){
#     ssp = ssps[s]
#     dir = paste0(model,"/",ssp)
#     dir.create(dir)
#   }
# }

# Create subdirectories for each variable (pr, tasmax, tasmin)
# for (m in 1:17){
#   model = models[m,1]
#   for (s in 1:4){
#     ssp = ssps[s]
#     for (i in 1:3){
#       v = vars[i]
#       dir = paste0(model,"/",ssp,"/",v)
#       dir.create(dir)
#     }
#   }
# }

######################################################################
####### Begin Subsetting Process for Model m = 13 ##################
######################################################################

# Define model-specific resolution (lon/lat) for the grid
lon_res <- 360 / 256  ###### Resolution may change for every model
lat_res <- 180 / 128  # Latitude resolution

m = 13 # Set model index to 13

# Get model information from the 'models' file
model = models[m,1]
realization = models[m,5]  # Model realization (ensemble member)
grid = models[m,6]  # Grid type used by the model

# Load the guide (coordinate mapping) for the model, adjusting the longitude to be within the range [0, 360]
guide <- read.dbf(paste0("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/guides/", model, "_guide.dbf"))
guide$lon1 <- ifelse(guide$lon < 0, (360 + guide$lon), guide$lon) # Adjust longitude if negative
guide <- guide[, c(4, 1:2, 5, 3)] # Reorder columns for convenience

# Iterate through each scenario (historical, SSP245, SSP370, SSP585)
for (s in 1:4) {
  ssp = ssps[s] # Select the scenario
  print(ssp) # Print current scenario
  
  # Initialize variable processing for each climate variable (pr, tasmax, tasmin)
  for (v in 1:3) {
    var = variables[v, 3] # Get variable name (pr, tasmax, etc.)
    print(var) # Print current variable name
    
    # Set the number of files to process based on the scenario and variable type
    if (ssp == "historical" & var == "pr") {dates_n = models[m, 8]}  # Number of files for "pr" variable in historical
    if (ssp == "historical" & (var == "tasmax" | var == "tasmin")) {dates_n = models[m, 7]}  # Number of files for temperature variables in historical
    if (ssp %in% c("ssp245", "ssp370", "ssp585")) {dates_n = models[m, 9]} # For future scenarios (SSPs)
    
    # Create vector of dates based on the scenario and variable
    if (ssp == "historical" & var == "pr") {dates = historical_dates[3, m]}
    if (ssp == "historical" & (var == "tasmax" | var == "tasmin")) {dates = historical_dates[1:dates_n, m]}
    if (ssp %in% c("ssp245", "ssp370", "ssp585")) {dates = future_dates[1:dates_n, m]}
    
    # Process data for historical scenario
    if (ssp == "historical") {
      for (d in 1:length(dates)) {
        date = dates[d]  # Get current date for processing
        print(date)  # Print the date being processed
        
        # Open the NetCDF file for the current date and variable
        nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/", var, "/", model, "/", ssp, "/", var, "_day_", model, "_", ssp, "_", realization, "_", grid, "_", date, ".nc")
        nc <- nc_open(nc_name)
        
        # Extract the array of variable data from the NetCDF file
        array <- ncvar_get(nc, var)
        
        # Initialize pixels array to store subset of data
        pixels = rep(NA, 12410)
        
        # Iterate over the grid cells and extract data based on the guide
        for (p in 1:length(guide$lon)) {
          in_out <- guide[p, 5]  # Get grid cell inclusion flag
          
          if (in_out == 0) {
            pixel = rep(NA, 365)  # No data for this pixel
          } 
          if (in_out == 1) {
            # Calculate X, Y positions for the grid cell
            Y <- ((guide[p, 3] + 90) / lat_res) + 1
            X <- (guide[p, 4] / lon_res) + 1
            
            # Extract pixel data based on variable type
            if (var == "pr") { pixel <- array[X, Y, 11324:23741] }
            if (var %in% c("tasmax", "tasmin")) { pixel <- array[X, Y, 47848:60265] }
          }
          
          # Remove leap year data (not necessary for all variables)
          for (r in 1:8) {
            remove <- (r * 1460) + 1
            pixel <- pixel[-remove]
          }
          
          pixels <- cbind(pixels, pixel)  # Append pixel data to the matrix
        }
        
        # Store the data from the first day
        if (d == 1) { pixels_d1 <- pixels[,-1] }
      }
      
      # Store the final subset data
      data <- pixels_d1
      
      # Define output directory and create the NetCDF file for the subset data
      setwd(paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_subset/", model, "/", ssp, "/", var))
      data <- as.data.frame(data)
      rownames(data) <- as.character(1:length(data$pixel))
      colnames(data) <- as.character(1:length(data))
      data <- t(data)
      
      LON_n <- length(unique(guide$lon))  # Number of unique longitudes
      LAT_n <- length(unique(guide$lat))  # Number of unique latitudes
      TIME_n <- 12410  # Number of time steps for historical data
      
      # Create the array for the NetCDF data
      data_array <- array(data, dim = c(LON_n, LAT_n, TIME_n))
      
      # Define the NetCDF file name and variable metadata
      nc_name <- paste0(var, "_day_", model, "_", realization, "_", ssp, "_subset.nc")
      dim_name <- variables[v, 3]
      dim_long_name <- variables[v, 5]
      dim_units <- variables[v, 7]
      
      # Define dimensions for the NetCDF file
      lon_dim <- ncdim_def("lon", units = "degrees_east", longname = "Longitude", vals = unique(guide$lon))
      lat_dim <- ncdim_def("lat", units = "degrees_north", longname = "Latitude", vals = unique(guide$lat))
      time_dim <- ncdim_def("time", units = "days", longname = "days since 19810101", vals = historical_days)
      
      # Define the variable and create the NetCDF file
      variable_dim <- ncvar_def(name = dim_name, units = dim_units, list(lon_dim, lat_dim, time_dim), missval = NA, longname = dim_long_name, prec = "double")
      nc_out <- nc_create(nc_name, variable_dim)
      ncvar_put(nc_out, variable_dim, data_array)
      nc_close(nc_out)
    }
    
    ##########################################################################
    
    # Process data for SSP scenarios (SSP245, SSP370, SSP585)
    if (ssp %in% c("ssp245", "ssp370", "ssp585")) {
      for (d in 1:length(dates)) {
        date = dates[d]
        print(date)
        
        # Open the NetCDF file for the current date
        nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/", var, "/", model, "/", ssp, "/", var, "_day_", model, "_", ssp, "_", realization, "_", grid, "_", date, ".nc")
        nc <- nc_open(nc_name)
        
        # Extract the variable data from the NetCDF file
        array <- ncvar_get(nc, var)
        
        # Initialize pixels array for future data
        pixels = rep(NA, 31390)
        
        # Iterate over the grid cells to extract data based on the guide
        for (p in 1:length(guide$lon)) {
          in_out <- guide[p, 5]
          
          if (in_out == 0) { pixel = rep(NA, 365) }
          if (in_out == 1) {
            # Calculate X, Y positions for grid cell
            Y <- ((guide[p, 3] + 90) / lat_res) + 1
            X <- (guide[p, 4] / lon_res) + 1
            
            # Extract pixel data for future scenarios
            pixel <- array[X, Y, 1:31411]
          }
          
          # Remove leap year data for future scenarios
          for (r in 1:21) {
            remove <- (r * 1460) + 1
            pixel <- pixel[-remove]
          }
          
          # Trim pixel data to the correct length
          pixel <- tail(pixel, 31390)
          pixels <- cbind(pixels, pixel)
        }
        
        if (d == 1) { pixels_d1 <- pixels[,-1] }
      }
      
      # Prepare and write the subsetted data to a NetCDF file
      data <- pixels_d1
      setwd(paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_subset/", model, "/", ssp, "/", var))
      data <- as.data.frame(data)
      rownames(data) <- as.character(1:length(data$pixel))
      colnames(data) <- as.character(1:length(data))
      data <- t(data)
      
      LON_n <- length(unique(guide$lon))
      LAT_n <- length(unique(guide$lat))
      TIME_n <- 31390
      
      # Create array for the NetCDF data
      data_array <- array(data, dim = c(LON_n, LAT_n, TIME_n))
      
      # Define output NetCDF file and variable metadata
      nc_name <- paste0(var, "_day_", model, "_", realization, "_", ssp, "_subset.nc")
      dim_name <- variables[v, 3]
      dim_long_name <- variables[v, 5]
      dim_units <- variables[v, 7]
      
      # Define dimensions for the NetCDF file
      lon_dim <- ncdim_def("lon", units = "degrees_east", longname = "Longitude", vals = unique(guide$lon))
      lat_dim <- ncdim_def("lat", units = "degrees_north", longname = "Latitude", vals = unique(guide$lat))
      time_dim <- ncdim_def("time", units = "days", longname = "days since 20150101", vals = ssp_days)
      
      # Create the NetCDF file and store the data
      variable_dim <- ncvar_def(name = dim_name, units = dim_units, list(lon_dim, lat_dim, time_dim), missval = NA, longname = dim_long_name, prec = "double")
      nc_out <- nc_create(nc_name, variable_dim)
      ncvar_put(nc_out, variable_dim, data_array)
      nc_close(nc_out)
    }
  }
}
