########################################
# Author - Andre Moraes
# Updated by Sajad Khoshnood
# Utah State University
# QCNR - Watershed Sciences Department
# andre.moraes@usu.edu & sajad.khoshnoodmotlagh@usu.edu

# This script is used to subset cmip6 models.

############ INM-CM4-8 models ####################

# Read input files: future and historical dates, model info, and variable info
future_dates <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/future_dates_2024.csv") 
historical_dates <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/historical_dates_2024.csv") # all dates for historical
models <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/models_2024.csv") 
variables <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/Variables.csv")
ssps <- c("historical","ssp245","ssp370","ssp585") # Different SSP scenarios

# Define the day ranges for historical and future periods
historical_days <- seq(1,12410,1)
ssp_days <- seq(12411,43800,1)

# Load required libraries
library(ncdf4)  # For working with NetCDF files
library(dplyr)  # For data manipulation
library(foreign)  # For reading .dbf files

#########################################################################
##### Creating directories for model output (if needed)
# getwd()
# setwd("/scratch/general/vast/u6047395/cmip6/cmip6_subset")
# 
# for (m in 1:17){
#   model = models[m,1]
#   dir.create(model)  # Create directory for each model
# }
# 
# for (m in 1:17){
#   model = models[m,1]
#   for (s in 1:4){
#     ssp = ssps[s]
#     dir = paste0(model,"/",ssp)
#     dir.create(dir)  # Create directories for each SSP
#   }
# }
# 
# for (m in 1:17){
#   model = models[m,1]
#   for (s in 1:4){
#     ssp = ssps[s]
#     for (i in 1:3){
#       v = vars[i]
#       dir = paste0(model,"/",ssp,"/",v)
#       dir.create(dir)  # Create directories for each variable
#     }
#   }
# }
####################################################################
####### Subsetting for model m = 5 ###################################
####################################################################

# Define model-specific information
lon_res <- 360 / 180  # Longitude resolution for the model
lat_res <- 180 / 120  # Latitude resolution for the model

# Select model m (in this case m = 5)
m = 5
model = models[m,1]  # Get the model name
realization = models[m,5]  # Get the realization
grid = models[m,6]  # Get the grid

# Read the guide DBF file that contains model-specific data
guide <- read.dbf(paste0("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/guides/",model,"_guide.dbf"))
guide$lon1 <- ifelse(guide$lon < 0, (360 + guide$lon), guide$lon)  # Correct for negative longitudes

# Organize the guide data for easy access
guide <- guide[,c(4,1:2,5,3)]

# Loop through each SSP scenario
for (s in 1:4){
  ssp = ssps[s]  # Get the SSP scenario
  print(ssp)
  
  # Determine the number of files based on the SSP
  if(ssp == "historical") {dates_n = models[m,7]}  # Historical data number of files
  if(ssp == "ssp245"|ssp == "ssp370"|ssp == "ssp585") {dates_n = models[m,9]}  # Future data number of files
  
  # Getting the date vectors based on the SSP scenario
  if(ssp == "historical") {dates = historical_dates[1:dates_n,m]}  # Historical dates
  if(ssp == "ssp245"|ssp == "ssp370"|ssp == "ssp585") {dates = future_dates[1:dates_n,m]}  # Future dates
  
  # Loop through each variable
  for (v in 1:3){
    var = variables[v,3]  # Get the variable name
    print(var)
    
    # Process historical data
    if(ssp == "historical") {
      for (d in 1:length(dates)){
        
        # Process the first date
        if (d == 1){
          date = dates[d]
          print(date)
          nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/",var,"/",model,"/",ssp,"/",var,"_day_",model,"_",ssp,"_",realization,"_",grid,"_",date,".nc")
          nc <- nc_open(nc_name)  # Open the NetCDF file
          
          # Collect model data from the NetCDF file
          array <- ncvar_get(nc, var)
          
          # Initialize the pixels data array
          pixels = rep(NA, 6935)
          p=1
          for (p in 1:length(guide$lon)){
            in_out <- guide[p,5]  # Check if the pixel is located in or out of the grid
            
            # If the pixel is included, get its value
            if(in_out == 1){
              Y <- ((guide[p,3] + 90)/lat_res)+1  # Calculate latitude index
              X <- (guide[p,4]/ lon_res)+1  # Calculate longitude index
              pixel <- array[X,Y, 11315:18250]  # Extract the pixel data
            }
            pixels <- cbind(pixels,pixel)  # Store the pixel data
          }
          
          if (d == 1) { pixels_d1 <- pixels[,-1] }  # Save the first set of pixels
        }
        
        # Process the second date
        if (d == 2){
          date = dates[d]
          print(date)
          nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/",var,"/",model,"/",ssp,"/",var,"_day_",model,"_",ssp,"_",realization,"_",grid,"_",date,".nc")
          nc <- nc_open(nc_name)  # Open the NetCDF file
          
          # Collect model data from the NetCDF file
          array <- ncvar_get(nc, var)
          
          # Initialize the pixels data array
          pixels = rep(NA, 5475)
          p=1
          for (p in 1:length(guide$lon)){
            in_out <- guide[p,5]  # Check if the pixel is included in the model
            
            # If the pixel is included, get its value
            if(in_out == 1){
              Y <- ((guide[p,3] + 90)/lat_res)+1  # Calculate latitude index
              X <- (guide[p,4]/ lon_res)+1  # Calculate longitude index
              pixel <- array[X,Y, 1:5475]  # Extract the pixel data
            }
            pixels <- cbind(pixels,pixel)  # Store the pixel data
          }
          
          if (d == 2) { pixels_d2 <- pixels[,-1] }  # Save the second set of pixels
        }
      }
      
      # Combine the pixel data from both dates
      data <- rbind(pixels_d1, pixels_d2)
      
      # Creating the output NetCDF file
      getwd()
      setwd(paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_subset/",model,"/",ssp,"/",var))  # Set the working directory
      
      data <- as.data.frame(data)  # Convert the data to a data frame
      rownames(data) <- as.character(1:length(data$pixel))
      colnames(data) <- as.character(1:length(data))
      data <- t(data)  # Transpose the data
      
      LON_n <- length(unique(guide$lon))  # Get the number of unique longitudes
      LAT_n <- length(unique(guide$lat))  # Get the number of unique latitudes
      TIME_n <- 12410  # Set the time dimension size
      
      data_array <-  array(data, dim = c(LON_n, LAT_n, TIME_n))  # Create a 3D array from the data
      
      # Define the dimensions for the NetCDF file
      lon_dim <- ncdim_def("lon", units = "degrees_east", longname = "Longitude", vals = unique(guide$lon))
      lat_dim <- ncdim_def("lat", units = "degrees_north", longname = "Latitude", vals = unique(guide$lat))
      time_dim <- ncdim_def("time", units = "days", longname = "days since 19810101", vals = historical_days)
      
      # Define the variable for the NetCDF file
      variable_dim <- ncvar_def(name = dim_name, units = dim_units, list(lon_dim, lat_dim, time_dim),
                                missval =  NA, longname = dim_long_name, prec = "double")
      
      # Create and write the NetCDF file
      nc_out <- nc_create(nc_name, variable_dim)
      ncvar_put(nc_out, variable_dim, data_array)
      nc_close(nc_out)  # Close the NetCDF file
    }
    
    ##########################################################################
    
    # Repeat for future SSPs (ssp245, ssp370, ssp585)
    if(ssp == "ssp245"|ssp == "ssp370"|ssp == "ssp585") {
      d=1
      for (d in 1:length(dates)){
        
        # Process the first date
        if (d == 1){
          date = dates[d]
          print(date)
          nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/",var,"/",model,"/",ssp,"/",var,"_day_",model,"_",ssp,"_",realization,"_",grid,"_",date,".nc")
          nc <- nc_open(nc_name)  # Open the NetCDF file
          
          # Collect model data from the NetCDF file
          array <- ncvar_get(nc, var)
          
          # Initialize the pixels data array
          pixels = rep(NA, 18250)
          p=1
          for (p in 1:length(guide$lon)){
            in_out <- guide[p,5]  # Check if the pixel is included in the model
            
            # If the pixel is included, get its value
            if(in_out == 1){
              Y <- ((guide[p,3] + 90)/lat_res)+1  # Calculate latitude index
              X <- (guide[p,4]/ lon_res)+1  # Calculate longitude index
              pixel <- array[X,Y, 1:18250]  # Extract the pixel data
            }
            pixels <- cbind(pixels,pixel)  # Store the pixel data
          }
          
          if (d == 1) { pixels_d1 <- pixels[,-1] }  # Save the first set of pixels
        }
        
        # Process the second date
        if (d == 2){
          date = dates[d]
          print(date)
          nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/",var,"/",model,"/",ssp,"/",var,"_day_",model,"_",ssp,"_",realization,"_",grid,"_",date,".nc")
          nc <- nc_open(nc_name)  # Open the NetCDF file
          
          # Collect model data from the NetCDF file
          array <- ncvar_get(nc, var)
          
          # Initialize the pixels data array
          pixels = rep(NA, 13140)
          p=1
          for (p in 1:length(guide$lon)){
            in_out <- guide[p,5]  # Check if the pixel is included in the model
            
            # If the pixel is included, get its value
            if(in_out == 1){
              Y <- ((guide[p,3] + 90)/lat_res)+1  # Calculate latitude index
              X <- (guide[p,4]/ lon_res)+1  # Calculate longitude index
              pixel <- array[X,Y, 1:13140]  # Extract the pixel data
            }
            pixels <- cbind(pixels,pixel)  # Store the pixel data
          }
          
          if (d == 2) { pixels_d2 <- pixels[,-1] }  # Save the second set of pixels
        }
      }
      
      # Combine the pixel data from both dates
      data <- rbind(pixels_d1, pixels_d2)
      
      # Creating the output NetCDF file
      getwd()
      setwd(paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_subset/",model,"/",ssp,"/",var))  # Set the working directory
      
      data <- as.data.frame(data)  # Convert the data to a data frame
      rownames(data) <- as.character(1:length(data$pixel))
      colnames(data) <- as.character(1:length(data))
      data <- t(data)  # Transpose the data
      
      LON_n <- length(unique(guide$lon))  # Get the number of unique longitudes
      LAT_n <- length(unique(guide$lat))  # Get the number of unique latitudes
      TIME_n <- 31390  # Set the time dimension size for future data
      
      data_array <-  array(data, dim = c(LON_n, LAT_n, TIME_n))  # Create a 3D array from the data
      
      # Define the dimensions for the NetCDF file
      lon_dim <- ncdim_def("lon", units = "degrees_east", longname = "Longitude", vals = unique(guide$lon))
      lat_dim <- ncdim_def("lat", units = "degrees_north", longname = "Latitude", vals = unique(guide$lat))
      time_dim <- ncdim_def("time", units = "days", longname = "days since 20150101", vals = ssp_days)
      
      # Define the variable for the NetCDF file
      variable_dim <- ncvar_def(name = dim_name, units = dim_units, list(lon_dim, lat_dim, time_dim),
                                missval =  NA, longname = dim_long_name, prec = "double")
      
      # Create and write the NetCDF file
      nc_out <- nc_create(nc_name, variable_dim)
      ncvar_put(nc_out, variable_dim, data_array)
      nc_close(nc_out)  # Close the NetCDF file
    }
  }
}
