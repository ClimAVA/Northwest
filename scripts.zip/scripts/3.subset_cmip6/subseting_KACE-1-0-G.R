########################################
# Author - Andre Moraes
# Updated by Sajad Khoshnood
# Utah State University
# QCNR - Watershed Sciences Department
# andre.moraes@usu.edu & sajad.khoshnoodmotlagh@usu.edu

# This script is used to subset CMIP6 model data.

############ KACE-1-0-G ####################

# Reading in various CSV files that contain model-specific data and dates
future_dates <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/future_dates_2024.csv") # All dates for the future
historical_dates <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/historical_dates_2024.csv") # All dates for historical data
models <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/models_2024.csv") # Model-specific metadata
variables <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/Variables.csv") # List of climate variables
ssps <- c("historical", "ssp245", "ssp370", "ssp585") # Defining SSP scenarios

# Defining the range of days for historical and future scenarios
historical_days <- seq(1, 12410, 1)
ssp_days <- seq(12411, 43800, 1)

# Loading required libraries
library(ncdf4)
library(dplyr)
library(foreign)

#########################################################################
## Creating directories (this section is commented out to avoid rerunning it)
## The following code creates directories for storing subsets of data for each model and scenario.
## Uncomment to use.

# getwd()
# setwd("/scratch/general/vast/u6047395/cmip6/cmip6_subset")
# 
# for (m in 1:17){
#   model = models[m,1]
#   dir.create(model) # Create model directory
# }
# 
# for (m in 1:17){
#   model = models[m,1]
#   for (s in 1:4){
#     ssp = ssps[s]
#     dir = paste0(model,"/",ssp)
#     dir.create(dir) # Create directory for each SSP scenario
#   }
# }
# 
# for (m in 1:17){
#   model = models[m,1]
#   for (s in 1:4){
#     ssp = ssps[s]
#     for (i in 1:3){
#       v = vars[i]
#       dir = paste0(model,"/",ssp,"/",v)
#       dir.create(dir) # Create directory for each variable
#     }
#   }
# }
####################################################################
####### SUBSETTING for model m = 15 ###################################----
####################################################################

# Model-specific settings
lon_res <- 360 / 192  ###### Resolution of the longitude grid, specific to each model
lat_res <- 180 / 144  ###### Resolution of the latitude grid, specific to each model

##############################################################

m = 15  # Model index (subsetting for the 15th model)

# Extracting model-specific metadata
model = models[m,1]
realization = models[m,5]
grid = models[m,6]

# Reading the model's guide file to map coordinates
guide <- read.dbf(paste0("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/guides/",model,"_guide.dbf"))
guide$lon1 <- ifelse(guide$lon < 0, (360 + guide$lon), guide$lon) # Adjust longitude for negative values

# Rearranging guide columns for easier access
guide <- guide[,c(4,1:2,5,3)] 

# Loop over the four SSP scenarios (historical, ssp245, ssp370, ssp585)
for (s in 1:4){
  ssp = ssps[s]
  print(ssp)
  
  # Set the number of dates based on the scenario
  if(ssp == "historical") {dates_n = models[m,7]} # Historical data count
  if(ssp == "ssp245" | ssp == "ssp370" | ssp == "ssp585") {dates_n = models[m,9]} # Future scenario data count
  
  # Set dates based on the scenario
  if(ssp == "historical") {dates = historical_dates[1:dates_n,m]} # Historical dates
  if(ssp == "ssp245" | ssp == "ssp370" | ssp == "ssp585") {dates = future_dates[1:dates_n,m]} # Future dates
  
  # Loop over the three climate variables
  for (v in 1:3){
    var = variables[v,3] # Get the variable name
    print(var)
    
    if(ssp == "historical") {
      
      # Loop over the dates
      for (d in 1:length(dates)){
        
        date = dates[d]
        print(date)
        # Construct the file path for the current date's data
        nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/",var,"/",model,"/",ssp,"/",var,"_day_",model,"_",ssp,"_",realization,"_",grid,"_",date,".nc")
        nc <- nc_open(nc_name)  # Open the NetCDF file
        
        # Extract the model data (array of climate variable values)
        array <- ncvar_get(nc, var)
        
        # Initialize an empty vector for storing pixel data
        pixels = rep(NA, 12410) 
        
        # Loop over all the grid pixels
        for (p in 1:length(guide$lon)){
          pixel_1 <- NA
          start = 1
          end <- 72
          in_out <- guide[p,5]  # Check if the pixel is located inside (1) or outside (0)
          
          # Handle inside and outside pixels differently
          if(in_out == 0){
            pixel = rep(NA, 365)  # outside pixels have no data
          }
          if(in_out == 1){
            # Calculate the pixel's location in the model's grid
            Y <- ((guide[p,3] + 90)/lat_res) + 1
            X <- (guide[p,4]/ lon_res) + 1
            pixel <- array[X, Y, 47160:59400]  # Extract the data for this pixel
          }
          
          # Loop over the time steps to chunk the data into smaller sections
          for (f in 1:170){  # 16 for precipitation (pr), 40 for other variables
            chunk <- pixel[start : end]
            chunk_full <- append(chunk, tail(chunk,1))  # Append the last value to the chunk for continuity
            pixel_1 <- append(pixel_1, chunk_full)
            start <- (f*72) + 1
            end <- (start + 71)
          }
          
          pixels <- cbind(pixels, pixel_1[-1])  # Append the pixel data
        }
        
        if (d == 1) { pixels_d1 <- pixels[,-1] }  # Save the data for the first date
        
      }
      
      # Create the NetCDF file to store the subset data
      data <- pixels_d1
      getwd()
      setwd(paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_subset/",model,"/",ssp,"/",var))
      
      data <- as.data.frame(data)
      rownames(data) <- as.character(1:length(data[,1]))
      colnames(data) <- as.character(1:length(data))
      data <- t(data)  # Transpose the data to match NetCDF dimensions
      
      # Define dimensions
      LON_n <- length(unique(guide$lon)) 
      LAT_n <- length(unique(guide$lat))
      TIME_n <- 12410
      
      data_array <- array(data, dim = c(LON_n, LAT_n, TIME_n))  # Create an array with the data
      
      # Create a NetCDF file and define its structure
      nc_name <- paste0(var,"_day_",model,"_",realization,"_",ssp,"_subset.nc")
      dim_name <- variables[v,3]
      dim_long_name <- variables[v,5]
      dim_units <- variables[v,7]
      
      # Define dimensions for longitude, latitude, and time
      lon_dim <- ncdim_def("lon", units = "degrees_east", longname = "Longitude", vals = unique(guide$lon))
      lat_dim <- ncdim_def("lat", units = "degrees_north", longname = "Latitude", vals = unique(guide$lat))
      time_dim <- ncdim_def("time", units = "days", longname = "days since 19810101", vals = historical_days)
      
      # Define the variable for the dataset
      variable_dim <- ncvar_def(name = dim_name, units = dim_units, list(lon_dim, lat_dim, time_dim),
                                missval = NA, longname = dim_long_name, prec = "double")
      
      # Create and write to the NetCDF file
      nc_out <- nc_create(nc_name, variable_dim)
      ncvar_put(nc_out, variable_dim, data_array)
      
      # Close the NetCDF file
      nc_close(nc_out)
    }
    
    ##########################################################################
    # Repeat the process for the future SSP scenarios (ssp245, ssp370, ssp585)
    if(ssp == "ssp245" | ssp == "ssp370" | ssp == "ssp585") {
      
      # Loop over the dates for future scenarios
      d = 1
      for (d in 1:length(dates)){
        
        date = dates[d]
        print(date)
        nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/",var,"/",model,"/",ssp,"/",var,"_day_",model,"_",ssp,"_",realization,"_",grid,"_",date,".nc")
        nc <- nc_open(nc_name)
        
        # Collecting model data
        array <- ncvar_get(nc, var)
        
        pixels = rep(NA, 31390)  # For future scenarios, more time steps
        p=1
        for (p in 1:length(guide$lon)){
          pixel_1 <- NA
          start = 1
          end <- 72
          in_out <- guide[p,5]
          
          if(in_out == 0){
            pixel = rep(NA, 365)
          }
          if(in_out == 1){
            Y <- ((guide[p,3] + 90)/lat_res) + 1
            X <- (guide[p,4]/ lon_res) + 1
            pixel <- array[X, Y, 1:30960]  # Extract data for this pixel
          }
          
          # Process data for each time step
          for (f in 1:430){
            chunk <- pixel[start : end]
            chunk_full <- append(chunk, tail(chunk,1))
            pixel_1 <- append(pixel_1, chunk_full)
            start <- (f*72) + 1
            end <- (start + 71)
          }
          
          pixels <- cbind(pixels, pixel_1[-1]) 
        }
        
        if (d == 1) { pixels_d1 <- pixels[,-1] }
      }
      
      # Process and save the data for future scenarios (similar to historical data)
      data <- pixels_d1
      
      getwd()
      setwd(paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_subset/",model,"/",ssp,"/",var))
      
      data <- as.data.frame(data)
      rownames(data) <- as.character(1:length(data[,1]))
      colnames(data) <- as.character(1:length(data))
      data <- t(data)
      
      LON_n <- length(unique(guide$lon)) 
      LAT_n <- length(unique(guide$lat))
      TIME_n <- 31390  # Different time steps for future scenarios
      
      data_array <- array(data, dim = c(LON_n, LAT_n, TIME_n))
      
      nc_name <- paste0(var,"_day_",model,"_",realization,"_",ssp,"_subset.nc")
      dim_name <- variables[v,3]
      dim_long_name <- variables[v,5]
      dim_units <- variables[v,7]
      
      # Define dimensions and create NetCDF file
      lon_dim <- ncdim_def("lon", units = "degrees_east", longname = "Longitude", vals = unique(guide$lon))
      lat_dim <- ncdim_def("lat", units = "degrees_north", longname = "Latitude", vals = unique(guide$lat))
      time_dim <- ncdim_def("time", units = "days", longname = "days since 20150101", vals = ssp_days)
      
      variable_dim <- ncvar_def(name = dim_name, units = dim_units, list(lon_dim, lat_dim, time_dim),
                                missval =  NA,longname = dim_long_name, prec = "double")
      
      # Create and write to the NetCDF file
      nc_out <- nc_create(nc_name, variable_dim)
      ncvar_put(nc_out, variable_dim, data_array)
      nc_close(nc_out)
      
    }
  }
}

# End of script
