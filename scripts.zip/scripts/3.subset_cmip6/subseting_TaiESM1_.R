########################################
# Author - Andre Moraes
# Updated by Sajad Khoshnood
# Utah State University
# QCNR - Watershed Sciences Department
# andre.moraes@usu.edu & sajad.khoshnoodmotlagh@usu.edu

# This script is used to subset cmip6 models.

####### SUBSETING m = 9 ###################################----
# Load future and historical dates, models, and variables for subsetting
future_dates <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/future_dates_2024.csv") # all dates for ssps
historical_dates <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/historical_dates_2024.csv") # all dates for historical
models <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/models_2024.csv") 
variables <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/Variables.csv") # variables info
ssps <- c("historical", "ssp245", "ssp370", "ssp585") # list of SSP scenarios

# Define days for historical and future scenarios
historical_days <- seq(1, 12410, 1)
ssp_days <- seq(12411, 43800, 1)

# Load necessary libraries
library(ncdf4)
library(dplyr)
library(foreign)

#########################################################################
##### Creating directories --------
# getwd()
# setwd("/scratch/general/vast/u6047395/cmip6/cmip6_subset")
# 
# for (m in 1:17){
#   model = models[m,1]
#   dir.create(model)  # Creates a directory for each model
# }
# 
# for (m in 1:17){
#   model = models[m,1]
#   for (s in 1:4){
#     ssp = ssps[s]
#     dir = paste0(model,"/",ssp)
#     dir.create(dir)  # Creates directories for each SSP
#   }
# }
# 
# for (m in 1:17){
#   model = models[m,1]
#   for (s in 1:4){
#     ssp = ssps[s]
#     for (i in 1:3){
#       v = vars[i]
#       dir = paste0(model,"/",ssp,"/",v)
#       dir.create(dir)  # Creates directories for each variable
#     }
#   }
# }
####################################################################
####### SUBSETTING m = 9 ###################################----
####################################################################

# Model-specific information: Resolution settings for longitude and latitude
lon_res <- 360 / 288  ###### CHANGES FOR EVERY MODEL
lat_res <- 180 / 192

##############################################################

m = 9 
model = models[m, 1]  # Model name
realization = models[m, 5]  # Realization info
grid = models[m, 6]  # Grid info

# Load the guide file for the specific model
guide <- read.dbf(paste0("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/guides/", model, "_guide.dbf"))
guide$lon1 <- ifelse(guide$lon < 0, (360 + guide$lon), guide$lon)  # Adjust longitude for negative values

guide <- guide[, c(4, 1:2, 5, 3)]  # Reorganize columns in guide

s = 1
for (s in 1:4){  # Loop through the 4 SSP scenarios
  ssp = ssps[s]
  print(ssp)
  
  # Set the number of files based on the scenario
  if(ssp == "historical") {dates_n = models[m, 7]}  # Number of historical files
  if(ssp == "ssp245" | ssp == "ssp370" | ssp == "ssp585") {dates_n = models[m, 9]}  # Number of future scenario files
  
  # Assign the correct dates based on the scenario
  if(ssp == "historical") {dates = historical_dates[1:dates_n, m]}  # Historical dates
  if(ssp == "ssp245" | ssp == "ssp370" | ssp == "ssp585") {dates = future_dates[1:dates_n, m]}  # Future dates
  
  v = 2
  for (v in 1:3){  # Loop through 3 variables
    var = variables[v, 3]  # Variable name
    print(var)
    
    if(ssp == "historical") {
      # Process historical data
      for (d in 1:length(dates)){
        
        # Process each date (different for each d)
        if (d == 1 | d == 2 | d == 3){
          date = dates[d]
          print(date)
          nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/", var, "/", model, "/", ssp, "/", var, "_day_", model, "_", ssp, "_", realization, "_", grid, "_", date, ".nc")
          nc <- nc_open(nc_name)
          
          array <- ncvar_get(nc, var)
          
          pixels = rep(NA, 3650)
          p = 1
          for (p in 1:length(guide$lon)){
            in_out <- guide[p, 5]
            
            # Check if the pixel is inside or outside the region
            if(in_out == 0){pixel = rep(NA, 365)}  # Outside the region
            if(in_out == 1){
              Y <- ((guide[p, 3] + 90)/lat_res) + 1  # Latitude index for the pixel
              X <- (guide[p, 4]/lon_res) + 1  # Longitude index for the pixel
              
              # Extract pixel data for the corresponding date
              if (d == 1){pixel <- array[X, Y, 366:3650]}  
              else {pixel <- array[X, Y, 1:3650]}
            }
            
            pixels <- cbind(pixels, pixel)  # Append pixel data
          }
          
          # Store pixel data for each date
          if (d == 1) { pixels_d1 <- pixels[,-1] }
          if (d == 2) { pixels_d2 <- pixels[,-1] }
          if (d == 3) { pixels_d3 <- pixels[,-1] }
        }
        
        if (d == 4){
          date = dates[d]
          print(date)
          nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/", var, "/", model, "/", ssp, "/", var, "_day_", model, "_", ssp, "_", realization, "_", grid, "_", date, ".nc")
          nc <- nc_open(nc_name)
          
          array <- ncvar_get(nc, var)
          
          pixels = rep(NA, 1825)
          p = 1
          for (p in 1:length(guide$lon)){
            in_out <- guide[p, 5]
            
            if(in_out == 0){pixel = rep(NA, 365)}  # Outside the region
            if(in_out == 1){
              Y <- ((guide[p, 3] + 90)/lat_res) + 1  # Y-coordinate for the pixel
              X <- (guide[p, 4]/lon_res) + 1  # X-coordinate for the pixel
              pixel <- array[X, Y, 1:1825]  # Extract pixel data for the corresponding date
            }
            
            pixels <- cbind(pixels, pixel)  # Append pixel data
          }
          
          if (d == 4) { pixels_d4 <- pixels[,-1] }
        }
      }
      
      # Combine all pixel data
      data <- rbind(pixels_d1, pixels_d2, pixels_d3, pixels_d4)
      
      # Creating the NetCDF file----
      
      getwd()
      setwd(paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_subset/", model, "/", ssp, "/", var))
      
      data <- as.data.frame(data)
      rownames(data) <- as.character(1:length(data$pixel))
      colnames(data) <- as.character(1:length(data))
      data <- t(data)
      
      LON_n <- length(unique(guide$lon))  # Number of unique longitudes
      LAT_n <- length(unique(guide$lat))  # Number of unique latitudes
      TIME_n <- 12410  # Total number of time steps for historical data
      
      # Create the data array for the NetCDF file
      data_array <- array(data, dim = c(LON_n, LAT_n, TIME_n))
      
      # Define NetCDF dimensions and variables
      nc_name <- paste0(var, "_day_", model, "_", realization, "_", ssp, "_subset.nc")
      dim_name <- variables[v, 3]
      dim_long_name <- variables[v, 5]
      dim_units <- variables[v, 7]
      
      lon_dim <- ncdim_def("lon", units = "degrees_east", longname = "Longitude", vals = unique(guide$lon))
      lat_dim <- ncdim_def("lat", units = "degrees_north", longname = "Latitude", vals = unique(guide$lat))
      time_dim <- ncdim_def("time", units = "days", longname = "days since 19810101", vals = historical_days)
      
      variable_dim <- ncvar_def(name = dim_name, units = dim_units, list(lon_dim, lat_dim, time_dim),
                                missval = NA, longname = dim_long_name, prec = "double")
      
      # Create the NetCDF file and write data
      nc_out <- nc_create(nc_name, variable_dim)
      ncvar_put(nc_out, variable_dim, data_array)
      nc_close(nc_out)
    }
    
    ##########################################################################
    
    if(ssp == "ssp245" | ssp == "ssp370" | ssp == "ssp585") {
      
      d = 1
      for (d in 1:length(dates)){
        # Process each date for the future scenarios
        if (d == 1 | d == 2 | d == 3 | d == 4 | d == 5 | d == 6 | d == 7 | d == 8){
          date = dates[d]
          print(date)
          nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/", var, "/", model, "/", ssp, "/", var, "_day_", model, "_", ssp, "_", realization, "_", grid, "_", date, ".nc")
          nc <- nc_open(nc_name)
          
          array <- ncvar_get(nc, var)
          
          pixels = rep(NA, 3650)
          p = 1
          for (p in 1:length(guide$lon)){
            in_out <- guide[p, 5]
            
            if(in_out == 0){pixel = rep(NA, 365)}  # Outside the region
            if(in_out == 1){
              Y <- ((guide[p, 3] + 90)/lat_res) + 1  # Y-coordinate for the pixel
              X <- (guide[p, 4]/lon_res) + 1  # X-coordinate for the pixel
              pixel <- array[X, Y, 1:3650]  # Extract pixel data
            }
            
            pixels <- cbind(pixels, pixel)  # Append pixel data
          }
          
          # Store pixel data for each date
          if (d == 1) { pixels_d1 <- pixels[,-1] }
          if (d == 2) { pixels_d2 <- pixels[,-1] }
          if (d == 3) { pixels_d3 <- pixels[,-1] }
          if (d == 4) { pixels_d4 <- pixels[,-1] }
          if (d == 5) { pixels_d5 <- pixels[,-1] }
          if (d == 6) { pixels_d6 <- pixels[,-1] }
          if (d == 7) { pixels_d7 <- pixels[,-1] }
          if (d == 8) { pixels_d8 <- pixels[,-1] }
          
        }
        
        if (d == 9) {
          date = dates[d]
          print(date)
          nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/", var, "/", model, "/", ssp, "/", var, "_day_", model, "_", ssp, "_", realization, "_", grid, "_", date, ".nc")
          nc <- nc_open(nc_name)
          
          array <- ncvar_get(nc, var)
          
          pixels = rep(NA, 1825)
          p = 1
          for (p in 1:length(guide$lon)){
            in_out <- guide[p, 5]
            
            if(in_out == 0){pixel = rep(NA, 365)}  # Outside the region
            if(in_out == 1){
              Y <- ((guide[p, 3] + 90)/lat_res) + 1  # Y-coordinate for the pixel
              X <- (guide[p, 4]/lon_res) + 1  # X-coordinate for the pixel
              pixel <- array[X, Y, 1:1825]  # Extract pixel data
            }
            
            pixels <- cbind(pixels, pixel)  # Append pixel data
          }
          
          # Store pixel data for the last date
          if (d == 9) { pixels_d9 <- pixels[,-1] }
        }
      }
      
      # Combine all pixel data for future scenarios
      data <- rbind(pixels_d1, pixels_d2, pixels_d3, pixels_d4, pixels_d5, pixels_d6,
                    pixels_d7, pixels_d8, pixels_d9)
      
      # Creating the NetCDF file----
      
      getwd()
      setwd(paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_subset/", model, "/", ssp, "/", var))
      
      data <- as.data.frame(data)
      rownames(data) <- as.character(1:length(data$pixel))
      colnames(data) <- as.character(1:length(data))
      data <- t(data)
      
      LON_n <- length(unique(guide$lon))  # Number of unique longitudes
      LAT_n <- length(unique(guide$lat))  # Number of unique latitudes
      TIME_n <- 31390  # Total number of time steps for future scenarios
      
      # Create the data array for the NetCDF file
      data_array <- array(data, dim = c(LON_n, LAT_n, TIME_n))
      
      # Define NetCDF dimensions and variables
      nc_name <- paste0(var, "_day_", model, "_", realization, "_", ssp, "_subset.nc")
      dim_name <- variables[v, 3]
      dim_long_name <- variables[v, 5]
      dim_units <- variables[v, 7]
      
      lon_dim <- ncdim_def("lon", units = "degrees_east", longname = "Longitude", vals = unique(guide$lon))
      lat_dim <- ncdim_def("lat", units = "degrees_north", longname = "Latitude", vals = unique(guide$lat))
      time_dim <- ncdim_def("time", units = "days", longname = "days since 20150101", vals = ssp_days)
      
      variable_dim <- ncvar_def(name = dim_name, units = dim_units, list(lon_dim, lat_dim, time_dim),
                                missval = NA, longname = dim_long_name, prec = "double")
      
      # Create the NetCDF file and write data
      nc_out <- nc_create(nc_name, variable_dim)
      ncvar_put(nc_out, variable_dim, data_array)
      nc_close(nc_out)
      
    }
  }
}


# Fim (End of script)
