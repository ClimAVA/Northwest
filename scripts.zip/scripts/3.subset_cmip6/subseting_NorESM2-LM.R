########################################
# Author - Andre Moraes
# Updated by Sajad Khoshnood
# Utah State University
# QCNR - Watershed Sciences Department
# andre.moraes@usu.edu & sajad.khoshnoodmotlagh@usu.edu

# This script is used to subset cmip6 models.
############ NorESM2-LM ####################
# Reading future and historical dates for 2024
future_dates <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/future_dates_2024.csv") # all dates for future
historical_dates <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/historical_dates_2024.csv") # all dates for historical
models <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/models_2024.csv") 
variables <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/Variables.csv") # CSV file of variables
ssps <- c("historical","ssp245","ssp370","ssp585") # List of SSP scenarios

# Defining the time steps for historical and future data
historical_days <- seq(1,12410,1)
ssp_days <- seq(12411,43800,1)

# Loading required libraries
library(ncdf4) # For handling NetCDF files
library(dplyr) # For data manipulation
library(foreign) # For reading DBF files

#########################################################################
##### Creating directories for model outputs --------
# # getwd() # Get the current working directory
# # setwd("/scratch/general/vast/u6047395/cmip6/cmip6_subset") # Set working directory
# 
# # Creating directories for each model and corresponding SSP scenarios
# for (m in 1:17){ # Looping through the 17 models
#   model = models[m,1] # Model name
#   dir.create(model) # Creating the model directory
# }
# 
# # Creating SSP subdirectories for each model
# for (m in 1:17){
#   model = models[m,1]
#   for (s in 1:4){
#     ssp = ssps[s]
#     dir = paste0(model,"/",ssp) # Path to the SSP folder
#     dir.create(dir) # Creating the directory for the SSP
#   }
# }
# 
# # Creating variable subdirectories under each model and SSP
# for (m in 1:17){
#   model = models[m,1]
#   for (s in 1:4){
#     ssp = ssps[s]
#     for (i in 1:3){
#       v = vars[i] # Variable name
#       dir = paste0(model,"/",ssp,"/",v) # Path to the variable directory
#       dir.create(dir) # Creating the directory for the variable
#     }
#   }
# }

####################################################################
####### Subsetting model 17 ###################################----
####################################################################

# Defining model-specific information for grid resolution
lon_res <- 360 / 144 # Longitude resolution for this model
lat_res <- 180 / 96  # Latitude resolution for this model

# Defining the model index and extracting model-specific information
m=17
model = models[m,1]
realization = models[m,5] # Realization
grid = models[m,6] # Grid information

# Reading the guide (coordinates and additional data) for this model
guide <- read.dbf(paste0("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/guides/",model,"_guide.dbf"))
guide$lon1 <- ifelse(guide$lon < 0, (360 + guide$lon), guide$lon) # Adjusting longitude for negative values

# Reorganizing the guide data
guide <- guide[,c(4,1:2,5,3)]

# Looping through the 4 SSP scenarios
for (s in 1:4){
  ssp = ssps[s]
  print(ssp) # Print the current SSP
  
  # Setting the number of files based on the SSP
  if(ssp == "historical") {dates_n = models[m,7]} # Number of historical files
  if(ssp == "ssp245"|ssp == "ssp370"|ssp == "ssp585") {dates_n = models[m,9]} # Number of future files
  
  # Assigning dates for the current SSP
  if(ssp == "historical") {dates = historical_dates[1:dates_n,m]} # Historical dates
  if(ssp == "ssp245"|ssp == "ssp370"|ssp == "ssp585") {dates = future_dates[1:dates_n,m]} # Future dates
  
  # Looping through the 3 variables
  for (v in 1:3){
    var = variables[v,3] # Variable name
    print(var) # Print the current variable
    
    # Process for the "historical" scenario
    if(ssp == "historical") {
      
      for (d in 1:length(dates)){
        
        if (d == 1| d==2 | d== 3){ # Handling the first three dates
          
          date = dates[d]
          print(date) # Print the date
          
          # Building the file name and opening the NetCDF file
          nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/",var,"/",model,"/",ssp,"/",var,"_day_",model,"_",ssp,"_",realization,"_",grid,"_",date,".nc")
          nc <- nc_open(nc_name) # Opening the NetCDF file
          
          # Extracting the data array for the variable
          array <- ncvar_get(nc, var)
          
          pixels = rep(NA, 3650) 
          p=1
          
          # Looping through all guide coordinates and extracting pixel data
          for (p in 1:length(guide$lon)){
            in_out <- guide[p,5] # Check if the pixel is inside the region
            
            # Handling missing pixels (in_out == 0)
            if(in_out == 0){pixel = rep(NA, 365)}
            if(in_out == 1){ # Processing valid pixels
              
              Y <- ((guide[p,3] + 90)/lat_res)+1 # Y pixel position for the NetCDF array
              X <- (guide[p,4]/ lon_res)+1 # X pixel position for the NetCDF array
              
              # Extracting data for the first date
              if (d==1){pixel <- array[X,Y, 366:3650]}
              else {pixel <- array[X,Y, 1:3650]}
            }
            
            pixels <- cbind(pixels,pixel) # Storing the pixel data
          }
          
          # Assigning the extracted pixel data to different variables
          if (d == 1) { pixels_d1 <- pixels[,-1] }
          if (d == 2) { pixels_d2 <- pixels[,-1] }
          if (d == 3) { pixels_d3 <- pixels[,-1] }
        }
        
        # Handling the 4th date
        if (d == 4){
          
          date = dates[d]
          print(date)
          
          # Building the file name and opening the NetCDF file
          nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/",var,"/",model,"/",ssp,"/",var,"_day_",model,"_",ssp,"_",realization,"_",grid,"_",date,".nc")
          nc <- nc_open(nc_name) # Opening the NetCDF file
          
          # Extracting the data array for the variable
          array <- ncvar_get(nc, var)
          
          pixels = rep(NA, 1825) 
          p=1
          
          # Looping through all guide coordinates and extracting pixel data
          for (p in 1:length(guide$lon)){
            in_out <- guide[p,5] # Check if the pixel is inside the region
            
            # Handling missing pixels (in_out == 0)
            if(in_out == 0){pixel = rep(NA, 365)}
            if(in_out == 1){ # Processing valid pixels
              Y <- ((guide[p,3] + 90)/lat_res)+1 # Y pixel position for the NetCDF array
              X <- (guide[p,4]/ lon_res)+1 # X pixel position for the NetCDF array
              pixel <- array[X,Y, 1:1825] # Adjusting the time index
            }
            
            pixels <- cbind(pixels,pixel) # Storing the pixel data
          }
          
          # Assigning the extracted pixel data to the 4th date variable
          if (d == 4) { pixels_d4 <- pixels[,-1] }
        }
      }
      
      data <- rbind(pixels_d1, pixels_d2, pixels_d3, pixels_d4) # Combining the data for all dates
      
      # Creating the NetCDF file
      getwd() # Get current working directory
      setwd(paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_subset/",model,"/",ssp,"/",var)) # Set output directory
      
      data <- as.data.frame(data) # Converting data to a dataframe
      rownames(data) <- as.character(1:length(data$pixel)) # Assigning row names
      colnames(data) <- as.character(1:length(data)) # Assigning column names
      data <- t(data) # Transposing the data for writing
      
      LON_n <- length(unique(guide$lon)) # Number of unique longitudes
      LAT_n <- length(unique(guide$lat)) # Number of unique latitudes
      TIME_n <- 12410 # Time steps for historical data
      
      data_array <-  array(data, dim = c(LON_n, LAT_n, TIME_n)) # Creating the data array for NetCDF
      
      # Defining NetCDF file and variable dimensions
      nc_name <- paste0(var,"_day_",model,"_",realization,"_",ssp,"_subset.nc") # NetCDF file name
      dim_name <- variables[v,3] # Variable name
      dim_long_name <- variables[v,5] # Variable long name
      dim_units <- variables[v,7] # Variable units
      
      # Defining dimensions
      lon_dim <- ncdim_def("lon", units = "degrees_east", longname = "Longitude", vals = unique(guide$lon))
      lat_dim <- ncdim_def("lat", units = "degrees_north", longname = "Latitude", vals = unique(guide$lat))
      time_dim <- ncdim_def("time", units = "days", longname = "days since 19810101", vals = historical_days)
      
      # Defining the variable and creating the NetCDF file
      variable_dim <- ncvar_def(name = dim_name, units = dim_units, list(lon_dim, lat_dim, time_dim),
                                missval =  NA,longname = dim_long_name, prec = "double")
      nc_out <- nc_create(nc_name,variable_dim) # Create NetCDF file
      ncvar_put(nc_out, variable_dim, data_array) # Write data to NetCDF
      
      nc_close(nc_out) # Close the NetCDF file
    }
    
    ##########################################################################
    
    # Process for SSP245, SSP370, and SSP585 scenarios (future data)
    if(ssp == "ssp245"|ssp == "ssp370"|ssp == "ssp585") {
      
      d=1
      for (d in 1:length(dates)){
        
        # Process for the first date
        if (d == 1){
          
          date = dates[d]
          print(date)
          
          # Building the file name and opening the NetCDF file
          nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/",var,"/",model,"/",ssp,"/",var,"_day_",model,"_",ssp,"_",realization,"_",grid,"_",date,".nc")
          nc <- nc_open(nc_name) # Opening the NetCDF file
          
          array <- ncvar_get(nc, var) # Extracting the variable data array
          
          pixels = rep(NA, 1825) 
          p=1
          
          # Looping through all guide coordinates and extracting pixel data
          for (p in 1:length(guide$lon)){
            in_out <- guide[p,5] # Check if the pixel is inside the region
            
            if(in_out == 0){pixel = rep(NA, 365)} # Handling missing pixels
            if(in_out == 1){ # Processing valid pixels
              Y <- ((guide[p,3] + 90)/lat_res)+1 # Y pixel position for the NetCDF array
              X <- (guide[p,4]/ lon_res)+1 # X pixel position for the NetCDF array
              pixel <- array[X,Y, 1:1825] # Adjusting the time index
            }
            
            pixels <- cbind(pixels,pixel) # Storing the pixel data
          }
          
          # Assigning the extracted pixel data to the first date variable
          if (d == 1) { pixels_d1 <- pixels[,-1] }
          
        }
        
        # Handling the next dates
        if (d==2 | d== 3 | d == 4| d == 5| d == 6| d == 7 | d== 8 | d == 9) {
          
          date = dates[d]
          print(date)
          
          # Building the file name and opening the NetCDF file
          nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/",var,"/",model,"/",ssp,"/",var,"_day_",model,"_",ssp,"_",realization,"_",grid,"_",date,".nc")
          nc <- nc_open(nc_name) # Opening the NetCDF file
          
          array <- ncvar_get(nc, var) # Extracting the variable data array
          
          pixels = rep(NA, 3650) 
          p=1
          
          # Looping through all guide coordinates and extracting pixel data
          for (p in 1:length(guide$lon)){
            in_out <- guide[p,5] # Check if the pixel is inside the region
            
            if(in_out == 0){pixel = rep(NA, 365)} # Handling missing pixels
            if(in_out == 1){ # Processing valid pixels
              Y <- ((guide[p,3] + 90)/lat_res)+1 # Y pixel position for the NetCDF array
              X <- (guide[p,4]/ lon_res)+1 # X pixel position for the NetCDF array
              pixel <- array[X,Y, 1:3650] # Adjusting the time index
            }
            
            pixels <- cbind(pixels,pixel) # Storing the pixel data
          }
          
          # Assigning the extracted pixel data to different date variables
          if (d == 2) { pixels_d2 <- pixels[,-1] }
          if (d == 3) { pixels_d3 <- pixels[,-1] }
          if (d == 4) { pixels_d4 <- pixels[,-1] }
          if (d == 5) { pixels_d5 <- pixels[,-1] }
          if (d == 6) { pixels_d6 <- pixels[,-1] }
          if (d == 7) { pixels_d7 <- pixels[,-1] }
          if (d == 8) { pixels_d8 <- pixels[,-1] }
          if (d == 9) { pixels_d9 <- pixels[,-1] }
          
        }
      }
      
      data <- rbind(pixels_d1, pixels_d2, pixels_d3, pixels_d4, pixels_d5, pixels_d6,
                    pixels_d7, pixels_d8, pixels_d9) # Combining the data for all dates
      
      # Creating the NetCDF file
      getwd() # Get current working directory
      setwd(paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_subset/",model,"/",ssp,"/",var)) # Set output directory
      
      data <- as.data.frame(data) # Converting data to a dataframe
      rownames(data) <- as.character(1:length(data$pixel)) # Assigning row names
      colnames(data) <- as.character(1:length(data)) # Assigning column names
      data <- t(data) # Transposing the data for writing
      
      LON_n <- length(unique(guide$lon)) # Number of unique longitudes
      LAT_n <- length(unique(guide$lat)) # Number of unique latitudes
      TIME_n <- 31390 # Time steps for future data
      
      data_array <-  array(data, dim = c(LON_n, LAT_n, TIME_n)) # Creating the data array for NetCDF
      
      # Defining NetCDF file and variable dimensions
      nc_name <- paste0(var,"_day_",model,"_",realization,"_",ssp,"_subset.nc") # NetCDF file name
      dim_name <- variables[v,3] # Variable name
      dim_long_name <- variables[v,5] # Variable long name
      dim_units <- variables[v,7] # Variable units
      
      # Defining dimensions
      lon_dim <- ncdim_def("lon", units = "degrees_east", longname = "Longitude", vals = unique(guide$lon))
      lat_dim <- ncdim_def("lat", units = "degrees_north", longname = "Latitude", vals = unique(guide$lat))
      time_dim <- ncdim_def("time", units = "days", longname = "days since 19810101", vals = ssp_days)
      
      # Defining the variable and creating the NetCDF file
      variable_dim <- ncvar_def(name = dim_name, units = dim_units, list(lon_dim, lat_dim, time_dim),
                                missval =  NA,longname = dim_long_name, prec = "double")
      nc_out <- nc_create(nc_name,variable_dim) # Create NetCDF file
      ncvar_put(nc_out, variable_dim, data_array) # Write data to NetCDF
      
      nc_close(nc_out) # Close the NetCDF file
    }
  }
}
