########################################
# Author - Andre Moraes
# Updated by Sajad Khoshnood
# Utah State University
# QCNR - Watershed Sciences Department
# andre.moraes@usu.edu & sajad.khoshnoodmotlagh@usu.edu

# This script is used to subset cmip6 models.
############ CNRM-CM6-1 ####################

# Load necessary CSV files with metadata
future_dates <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/future_dates_2024.csv") # All future dates for ssp245
historical_dates <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/historical_dates_2024.csv") # All historical dates
models <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/models_2024.csv") 
variables <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/Variables.csv") # Variables of interest (pr, tasmax, tasmin, etc.)
ssps <- c("historical", "ssp245", "ssp370", "ssp585") # SSP scenarios

# Sequence for the number of days in historical and future scenarios
historical_days <- seq(1, 12410, 1)
ssp_days <- seq(12411, 43800, 1)

# Load necessary libraries
library(ncdf4)
library(dplyr)
library(foreign)

#########################################################################
##### Creating directories for model subsetting
# Create the necessary directories based on models, SSPS, and variables
# Uncomment below lines if directory creation is needed

# for (m in 1:17){
#   model = models[m, 1]
#   dir.create(model)
# }

# for (m in 1:17){
#   model = models[m, 1]
#   for (s in 1:4){
#     ssp = ssps[s]
#     dir = paste0(model, "/", ssp)
#     dir.create(dir)
#   }
# }

# for (m in 1:17){
#   model = models[m, 1]
#   for (s in 1:4){
#     ssp = ssps[s]
#     for (i in 1:3){
#       v = vars[i]
#       dir = paste0(model, "/", ssp, "/", v)
#       dir.create(dir)
#     }
#   }
# }
####################################################################
####### SUBSETTING model = 10 ###################################
####################################################################

# Model specific information
lon_res <- 360 / 256  ###### Change based on model
lat_res <- 180 / 128

# Select model (m=10 in this case)
m = 10
model = models[m, 1]
realization = models[m, 5]
grid = models[m, 6]

# Load model-specific guide (coordinates and other info)
guide <- read.dbf(paste0("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/guides/", model, "_guide.dbf"))
guide$lon1 <- ifelse(guide$lon < 0, (360 + guide$lon), guide$lon)
guide <- guide[, c(4, 1:2, 5, 3)] # Reorganize columns for convenience

# Loop over each SSP (historical, ssp245, ssp370, ssp585)
for (s in 1:4) {
  ssp = ssps[s]
  print(ssp)
  
  # Variables of interest (pr, tasmax, tasmin)
  for (v in 1:3) {
    var = variables[v, 3]
    print(var)
    
    # Determine number of files based on SSP and variable
    if (ssp == "historical" & var == "pr") { dates_n = models[m, 8] }
    if (ssp == "historical" & c(var == "tasmax" | var == "tasmin")) { dates_n = models[m, 7] }
    if (ssp == "ssp245" | ssp == "ssp370" | ssp == "ssp585") { dates_n = models[m, 9] }
    
    # Set the correct dates based on the SSP and variable
    if (ssp == "historical" & var == "pr") { dates = historical_dates[3, m] }
    if (ssp == "historical" & c(var == "tasmax" | var == "tasmin")) { dates = historical_dates[1:dates_n, m] }
    if (ssp == "ssp245" | ssp == "ssp370" | ssp == "ssp585") { dates = future_dates[1:dates_n, m] }
    
    #### Subsetting for Historical and Future Dates
    if (ssp == "historical") {
      
      # Loop through the dates for historical period
      for (d in 1:length(dates)) {
        date = dates[d]
        print(date)
        
        # Open the corresponding netCDF file
        nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/", var, "/", model, "/", ssp, "/", var, "_day_", model, "_", ssp, "_", realization, "_", grid, "_", date, ".nc")
        nc <- nc_open(nc_name)
        
        # Extract the model data array
        array <- ncvar_get(nc, var)
        
        # Initialize pixels as NA (for each pixel's time series)
        pixels = rep(NA, 12410) 
        
        # Loop over each grid point and extract the data
        for (p in 1:length(guide$lon)) {
          in_out <- guide[p, 5]
          
          # If pixel is outside the region, fill with NA
          if (in_out == 0) { pixel = rep(NA, 365) }
          if (in_out == 1) {
            Y <- ((guide[p, 3] + 90) / lat_res) + 1
            X <- (guide[p, 4] / lon_res) + 1
            
            # Extract data for "pr" variable or temperature variables
            if (var == "pr") { pixel <- array[X, Y, 11324:23741] } 
            if (var == "tasmax" | var == "tasmin") { pixel <- array[X, Y, 47848:60265] }
          }
          
          # Remove leap years (every 4th year)
          for (r in 1:8) {
            remove <- (r * 1460) + 1
            pixel <- pixel[-remove]
          }
          
          pixels <- cbind(pixels, pixel)
        }
        
        if (d == 1) { pixels_d1 <- pixels[,-1] } # Store the data for the first date
      }
      
      # Prepare data for NetCDF output
      data <- pixels_d1
      setwd(paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_subset/", model, "/", ssp, "/", var))
      
      data <- as.data.frame(data)
      rownames(data) <- as.character(1:length(data$pixel))
      colnames(data) <- as.character(1:length(data))
      data <- t(data)
      
      # Set dimensions for NetCDF output
      LON_n <- length(unique(guide$lon)) 
      LAT_n <- length(unique(guide$lat))
      TIME_n <- 12410 
      
      data_array <- array(data, dim = c(LON_n, LAT_n, TIME_n))
      
      # Define NetCDF output file name and metadata
      nc_name <- paste0(var, "_day_", model, "_", realization, "_", ssp, "_subset.nc")
      dim_name <- variables[v, 3]
      dim_long_name <- variables[v, 5]
      dim_units <- variables[v, 7]
      
      # Define dimensions for the NetCDF file
      lon_dim <- ncdim_def("lon", units = "degrees_east", longname = "Longitude", vals = unique(guide$lon))
      lat_dim <- ncdim_def("lat", units = "degrees_north", longname = "Latitude", vals = unique(guide$lat))
      time_dim <- ncdim_def("time", units = "days", longname = "days since 19810101", vals = historical_days)
      
      variable_dim <- ncvar_def(name = dim_name, units = dim_units, list(lon_dim, lat_dim, time_dim),
                                missval = NA, longname = dim_long_name, prec = "double")
      
      # Create and write the NetCDF file
      nc_out <- nc_create(nc_name, variable_dim)
      ncvar_put(nc_out, variable_dim, data_array)
      nc_close(nc_out)
    }
    
    ##########################################################################
    
    # Subsetting for Future (SSP245, SSP370, SSP585)
    if (ssp == "ssp245" | ssp == "ssp370" | ssp == "ssp585") {
      # Loop through the dates for future period
      for (d in 1:length(dates)) {
        date = dates[d]
        print(date)
        
        # Open the corresponding netCDF file
        nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/", var, "/", model, "/", ssp, "/", var, "_day_", model, "_", ssp, "_", realization, "_", grid, "_", date, ".nc")
        nc <- nc_open(nc_name)
        
        # Extract the model data array
        array <- ncvar_get(nc, var)
        
        # Initialize pixels as NA (for each pixel's time series)
        pixels = rep(NA, 31390) 
        
        # Loop over each grid point and extract the data
        for (p in 1:length(guide$lon)) {
          in_out <- guide[p, 5]
          
          # If pixel is outside the region, fill with NA
          if (in_out == 0) { pixel = rep(NA, 365) }
          if (in_out == 1) {
            Y <- ((guide[p, 3] + 90) / lat_res) + 1
            X <- (guide[p, 4] / lon_res) + 1
            pixel <- array[X, Y, 1:31411]  # Change according to model
          }
          
          # Remove leap years for certain variables (every 4th year)
          for (r in 1:21) {
            remove <- (r * 1460) + 1
            pixel <- pixel[-remove]
          }
          pixel <- tail(pixel, 31390)  # Keep the last valid data
          
          pixels <- cbind(pixels, pixel)
        }
        
        if (d == 1) { pixels_d1 <- pixels[,-1] } # Store the data for the first date
      }
      
      # Prepare data for NetCDF output
      data <- pixels_d1
      setwd(paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_subset/", model, "/", ssp, "/", var))
      
      data <- as.data.frame(data)
      rownames(data) <- as.character(1:length(data$pixel))
      colnames(data) <- as.character(1:length(data))
      data <- t(data)
      
      # Set dimensions for NetCDF output
      LON_n <- length(unique(guide$lon)) 
      LAT_n <- length(unique(guide$lat))
      TIME_n <- 31390 
      
      data_array <- array(data, dim = c(LON_n, LAT_n, TIME_n))
      
      # Define NetCDF output file name and metadata
      nc_name <- paste0(var, "_day_", model, "_", realization, "_", ssp, "_subset.nc")
      dim_name <- variables[v, 3]
      dim_long_name <- variables[v, 5]
      dim_units <- variables[v, 7]
      
      # Define dimensions for the NetCDF file
      lon_dim <- ncdim_def("lon", units = "degrees_east", longname = "Longitude", vals = unique(guide$lon))
      lat_dim <- ncdim_def("lat", units = "degrees_north", longname = "Latitude", vals = unique(guide$lat))
      time_dim <- ncdim_def("time", units = "days", longname = "days since 20150101", vals = ssp_days)
      
      variable_dim <- ncvar_def(name = dim_name, units = dim_units, list(lon_dim, lat_dim, time_dim),
                                missval = NA, longname = dim_long_name, prec = "double")
      
      # Create and write the NetCDF file
      nc_out <- nc_create(nc_name, variable_dim)
      ncvar_put(nc_out, variable_dim, data_array)
      nc_close(nc_out)
    }
  }
}
