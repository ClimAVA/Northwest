########################################
# Author - Andre Moraes
# Updated by Sajad Khoshnood
# Utah State University
# QCNR - Watershed Sciences Department
# andre.moraes@usu.edu & sajad.khoshnoodmotlagh@usu.edu

# This script is used to subset cmip6 models.

############ INM-CM5-0 model ####################

# Read in various CSV files with dates, models, variables, and SSP scenarios
future_dates <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/future_dates_2024.csv") # all dates for future
historical_dates <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/historical_dates_2024.csv") # all dates for historical
models <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/models_2024.csv") 
variables <- read.csv("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/excel_files/Variables.csv")
ssps <- c("historical", "ssp245", "ssp370", "ssp585")

# Define the day ranges for historical and SSP data
historical_days <- seq(1, 12410, 1)
ssp_days <- seq(12411, 43800, 1)

# Load required libraries
library(ncdf4)
library(dplyr)
library(foreign)

#########################################################################
##### Creating directories (commented out) --------
## Get current working directory
# setwd("/scratch/general/vast/u6047395/cmip6/cmip6_subset")
# Create directories for models
# for (m in 1:17){
#   model = models[m,1]
#   dir.create(model)
# }

## Create directories for scenarios (ssp)
# for (m in 1:17){
#   model = models[m,1]
#   for (s in 1:4){
#     ssp = ssps[s]
#     dir = paste0(model,"/",ssp)
#     dir.create(dir)
#   }
# }

## Create directories for variables under each scenario
# for (m in 1:17){
#   model = models[m,1]
#   for (s in 1:4){
#     ssp = ssps[s]
#     for (i in 1:3){
#       v = vars[i]
#       dir = paste0(model,"/",ssp,"/",v)
#       dir.create(dir)
#     }
#   }
# }
####################################################################

####### SUBSETTING m = 6 ###################################----
####################################################################

# Model-specific information (resolution and grid)
lon_res <- 360 / 180 ###### CHANGES FOR EVERY MODEL
lat_res <- 180 / 120

##############################################################

m=6

# Extract the model name and associated variables
model = models[m,1]
realization = models[m,5]
grid = models[m,6]

# Load the guide file (DBF format) for this model
guide <- read.dbf(paste0("/uufs/chpc.utah.edu/common/home/u6055107/Documents/codes/climava_nw/guides/", model, "_guide.dbf"))

# Adjust longitude values for correct hemisphere
guide$lon1 <- ifelse(guide$lon < 0, (360 + guide$lon), guide$lon)

# Reorganize the columns of the guide for easier access
guide <- guide[, c(4, 1:2, 5, 3)]

# Loop through SSP scenarios
for (s in 1:4){
  ssp = ssps[s]
  print(ssp)
  
  # Set the number of files based on the scenario
  if(ssp == "historical") {dates_n = models[m,7]} # number of files for historical
  if(ssp == "ssp245" | ssp == "ssp370" | ssp == "ssp585") {dates_n = models[m,9]} # number of files for SSPs
  
  # Assign the correct dates based on the scenario
  if(ssp == "historical") {dates = historical_dates[1:dates_n, m]} # creating a vector of the dates for historical
  if(ssp == "ssp245" | ssp == "ssp370" | ssp == "ssp585") {dates = future_dates[1:dates_n, m]} # creating a vector of the dates for future scenarios
  
  # Loop through each variable
  for (v in 1:3){
    var = variables[v, 3]
    print(var)
    
    if(ssp == "historical") {
      
      # Loop through each date in the historical data
      for (d in 1:length(dates)){
        
        # Process the first date (d == 1)
        if (d == 1){
          date = dates[d]
          print(date)
          nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/", var, "/", model, "/", ssp, "/", var, "_day_", model, "_", ssp, "_", realization, "_", grid, "_", date, ".nc")
          nc <- nc_open(nc_name)
          
          # Extract data for the variable
          array <- ncvar_get(nc, var)
          
          # Initialize an empty array to store the pixel data
          pixels = rep(NA, 6935)
          p = 1
          
          # Loop through each pixel in the guide file
          for (p in 1:length(guide$lon)){
            
            # Check if the pixel is inside or outside the defined region
            in_out <- guide[p, 5]
            
            # If inside, extract the data for the pixel
            if(in_out == 0){pixel = rep(NA, 365)}
            if(in_out == 1){
              Y <- ((guide[p, 3] + 90) / lat_res) + 1 # Latitude index for the pixel
              X <- (guide[p, 4] / lon_res) + 1 # Longitude index for the pixel
              pixel <- array[X, Y, 11315:18250]} # Time range for historical data
            
            pixels <- cbind(pixels, pixel) # Append pixel data
          }
          
          # Store the data for the first date
          if (d == 1) { pixels_d1 <- pixels[,-1] }
        }
        
        # Process the second date (d == 2)
        if (d == 2){
          date = dates[d]
          print(date)
          nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/", var, "/", model, "/", ssp, "/", var, "_day_", model, "_", ssp, "_", realization, "_", grid, "_", date, ".nc")
          nc <- nc_open(nc_name)
          
          # Extract data for the variable
          array <- ncvar_get(nc, var)
          
          # Initialize an empty array to store the pixel data
          pixels = rep(NA, 5475)
          p = 1
          
          # Loop through each pixel in the guide file
          for (p in 1:length(guide$lon)){
            in_out <- guide[p, 5]
            
            # If inside, extract the data for the pixel
            if(in_out == 0){pixel = rep(NA, 365)}
            if(in_out == 1){
              Y <- ((guide[p, 3] + 90) / lat_res) + 1 # Latitude index for the pixel
              X <- (guide[p, 4] / lon_res) + 1 # Longitude index for the pixel
              pixel <- array[X, Y, 1:5475]} # Time range for historical data
            
            pixels <- cbind(pixels, pixel) # Append pixel data
          }
          
          # Store the data for the second date
          if (d == 2) { pixels_d2 <- pixels[,-1] }
        }
      }
      
      # Combine the data for both dates
      data <- rbind(pixels_d1, pixels_d2)
      
      # Creating the NetCDF file for historical data
      getwd()
      setwd(paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_subset/", model, "/", ssp, "/", var))
      
      # Convert data to a data frame and transpose it
      data <- as.data.frame(data)
      rownames(data) <- as.character(1:length(data$pixel))
      colnames(data) <- as.character(1:length(data))
      data <- t(data)
      
      # Define dimensions
      LON_n <- length(unique(guide$lon))
      LAT_n <- length(unique(guide$lat))
      TIME_n <- 12410
      
      # Create the data array for the NetCDF file
      data_array <- array(data, dim = c(LON_n, LAT_n, TIME_n))
      
      # Define the NetCDF file name
      nc_name <- paste0(var, "_day_", model, "_", realization, "_", ssp, "_subset.nc")
      dim_name <- variables[v, 3]
      dim_long_name <- variables[v, 5]
      dim_units <- variables[v, 7]
      
      # Define dimensions for the NetCDF file
      lon_dim <- ncdim_def("lon", units = "degrees_east", longname = "Longitude", vals = unique(guide$lon))
      lat_dim <- ncdim_def("lat", units = "degrees_north", longname = "Latitude", vals = unique(guide$lat))
      time_dim <- ncdim_def("time", units = "days", longname = "days since 19810101", vals = historical_days)
      
      # Define the variable for the NetCDF file
      variable_dim <- ncvar_def(name = dim_name, units = dim_units, list(lon_dim, lat_dim, time_dim), missval = NA, longname = dim_long_name, prec = "double")
      
      # Create the NetCDF file and write the data
      nc_out <- nc_create(nc_name, variable_dim)
      ncvar_put(nc_out, variable_dim, data_array)
      nc_close(nc_out)
    }
    
    ##########################################################################
    
    if(ssp == "ssp245" | ssp == "ssp370" | ssp == "ssp585") {
      
      # Loop through each date in the future SSP data
      d = 1
      for (d in 1:length(dates)){
        
        # Process the first date (d == 1)
        if (d == 1){
          date = dates[d]
          print(date)
          nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/", var, "/", model, "/", ssp, "/", var, "_day_", model, "_", ssp, "_", realization, "_", grid, "_", date, ".nc")
          nc <- nc_open(nc_name)
          
          # Extract data for the variable
          array <- ncvar_get(nc, var)
          
          # Initialize an empty array to store the pixel data
          pixels = rep(NA, 18250)
          p = 1
          
          # Loop through each pixel in the guide file
          for (p in 1:length(guide$lon)){
            in_out <- guide[p, 5]
            
            # If inside, extract the data for the pixel
            if(in_out == 0){pixel = rep(NA, 365)}
            if(in_out == 1){
              Y <- ((guide[p, 3] + 90) / lat_res) + 1 # Latitude index for the pixel
              X <- (guide[p, 4] / lon_res) + 1 # Longitude index for the pixel
              pixel <- array[X, Y, 1:18250]} # Time range for future data
            
            pixels <- cbind(pixels, pixel) # Append pixel data
          }
          
          # Store the data for the first date
          if (d == 1) { pixels_d1 <- pixels[,-1] }
        }
        
        # Process the second date (d == 2)
        if (d == 2){
          date = dates[d]
          print(date)
          nc_name <- paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_2024_downloading_nw/", var, "/", model, "/", ssp, "/", var, "_day_", model, "_", ssp, "_", realization, "_", grid, "_", date, ".nc")
          nc <- nc_open(nc_name)
          
          # Extract data for the variable
          array <- ncvar_get(nc, var)
          
          # Initialize an empty array to store the pixel data
          pixels = rep(NA, 13140)
          p = 1
          
          # Loop through each pixel in the guide file
          for (p in 1:length(guide$lon)){
            in_out <- guide[p, 5]
            
            # If inside, extract the data for the pixel
            if(in_out == 0){pixel = rep(NA, 365)}
            if(in_out == 1){
              Y <- ((guide[p, 3] + 90) / lat_res) + 1 # Latitude index for the pixel
              X <- (guide[p, 4] / lon_res) + 1 # Longitude index for the pixel
              pixel <- array[X, Y, 1:13140]} # Time range for future data
            
            pixels <- cbind(pixels, pixel) # Append pixel data
          }
          
          # Store the data for the second date
          if (d == 2) { pixels_d2 <- pixels[,-1] }
        }
      }
      
      # Combine the data for both dates
      data <- rbind(pixels_d1, pixels_d2)
      
      # Creating the NetCDF file for future SSP data
      getwd()
      setwd(paste0("/scratch/general/vast/u6055107/climava_nw/cmip6_subset/", model, "/", ssp, "/", var))
      
      # Convert data to a data frame and transpose it
      data <- as.data.frame(data)
      rownames(data) <- as.character(1:length(data$pixel))
      colnames(data) <- as.character(1:length(data))
      data <- t(data)
      
      # Define dimensions
      LON_n <- length(unique(guide$lon))
      LAT_n <- length(unique(guide$lat))
      TIME_n <- 31390
      
      # Create the data array for the NetCDF file
      data_array <- array(data, dim = c(LON_n, LAT_n, TIME_n))
      
      # Define the NetCDF file name
      nc_name <- paste0(var, "_day_", model, "_", realization, "_", ssp, "_subset.nc")
      dim_name <- variables[v, 3]
      dim_long_name <- variables[v, 5]
      dim_units <- variables[v, 7]
      
      # Define dimensions for the NetCDF file
      lon_dim <- ncdim_def("lon", units = "degrees_east", longname = "Longitude", vals = unique(guide$lon))
      lat_dim <- ncdim_def("lat", units = "degrees_north", longname = "Latitude", vals = unique(guide$lat))
      time_dim <- ncdim_def("time", units = "days", longname = "days since 19810101", vals = historical_days)
      
      # Define the variable for the NetCDF file
      variable_dim <- ncvar_def(name = dim_name, units = dim_units, list(lon_dim, lat_dim, time_dim), missval = NA, longname = dim_long_name, prec = "double")
      
      # Create the NetCDF file and write the data
      nc_out <- nc_create(nc_name, variable_dim)
      ncvar_put(nc_out, variable_dim, data_array)
      nc_close(nc_out)
    }
  }
}
